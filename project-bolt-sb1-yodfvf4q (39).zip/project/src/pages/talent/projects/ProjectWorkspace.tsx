import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { CalendarIcon, Clock, ExternalLink, AlertTriangle } from 'lucide-react';
import { format, formatDistanceToNow } from 'date-fns';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import ProjectTimeline from '@/components/ProjectTimeline';
import DeliverablesPanel from '@/components/DeliverablesPanel';
import ActivityLog from '@/components/ActivityLog';
import ChatPanel from '@/components/ChatPanel';
import { useProjectStatus } from '@/hooks/useProjectStatus';

export default function ProjectWorkspace() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [projectName] = useState("SEO Optimization");
  const [projectDeadline] = useState(new Date(Date.now() + 14 * 24 * 60 * 60 * 1000));
  const [projectStartDate] = useState(new Date());
  const [estimatedHours] = useState(40);
  const [hourlyRate] = useState(75);
  const [estimatedBudget] = useState(estimatedHours * hourlyRate);
  const [messages, setMessages] = useState([]);

  console.log('🚀 ProjectWorkspace mounted with ID:', id);

  // Use centralized project status management with project ID
  const {
    projectStatus,
    deliverables,
    activityLog,
    loading,
    hasTrackingInfo,
    isArchived,
    isAssignedToTalent,
    canAccess,
    updateDeliverableStatus = () => {},
    addDeliverable = () => {},
    updateDeliverable = () => {},
    addActivityLogEntry = () => {}
  } = useProjectStatus(id);

  console.log('📊 ProjectWorkspace status:', {
    projectStatus,
    deliverablesCount: deliverables.length,
    canAccess: canAccess(),
    loading
  });

  // Check workspace access
  useEffect(() => {
    if (!loading && !canAccess()) {
      console.log('❌ Workspace access denied, redirecting to details');
      navigate(`/talent/projects/${id}/details`);
    }
  }, [loading, canAccess, navigate, id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F0F4FF] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#2E3A8C] mx-auto mb-4"></div>
          <p className="text-[#2E3A8C]">Loading project workspace...</p>
        </div>
      </div>
    );
  }

  if (!canAccess()) {
    return (
      <div className="min-h-screen bg-[#F0F4FF] flex items-center justify-center">
        <div className="max-w-md mx-auto text-center">
          <Alert className="border-yellow-200 bg-yellow-50">
            <AlertTriangle className="h-4 w-4 text-yellow-600" />
            <AlertDescription className="text-yellow-800">
              <div className="font-semibold mb-2">Workspace Not Available</div>
              <p className="text-sm">
                The project workspace is only accessible after the project has been picked up. 
                Current status: {projectStatus}
              </p>
            </AlertDescription>
          </Alert>
          <Button 
            onClick={() => navigate(`/talent/projects/${id}/details`)}
            className="mt-4"
          >
            View Project Details
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F0F4FF]">
      <div className="max-w-5xl mx-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-[#2E3A8C]">{projectName}</h1>
        </div>

        <ProjectTimeline status={projectStatus} role="talent" />

        <div className="bg-white border border-[#E6E9F4] rounded-lg p-4 mb-6">
          <div className="flex justify-between items-start">
            <div>
              <div className="flex items-center gap-3">
                <Badge variant="secondary">
                  <Clock className="mr-1 h-3 w-3" />
                  {projectStatus}
                </Badge>
                <Badge variant="outline" className="bg-yellow-50 text-yellow-800 border-yellow-200">
                  Due {formatDistanceToNow(projectDeadline, { addSuffix: true })}
                </Badge>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  asChild 
                  className="text-[#2E3A8C] hover:text-[#1B276F]"
                >
                  <Link to={`/talent/projects/${id}/details`} className="flex items-center gap-1">
                    <ExternalLink className="h-4 w-4" />
                    View Details
                  </Link>
                </Button>
              </div>
              <div className="flex items-center gap-4 text-sm text-gray-600">
                <div className="flex items-center gap-2">
                  <CalendarIcon className="w-4 h-4 text-[#2E3A8C]" />
                  <span>Deadline: {format(projectDeadline, 'PPP')}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-[#2E3A8C]" />
                  <span>{estimatedHours} hours @ ${hourlyRate}/hr</span>
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm font-medium text-[#2E3A8C]">
                Your Earnings: ${(estimatedBudget * 0.85).toLocaleString()}
              </div>
              <div className="text-xs text-gray-500">
                (85% of ${estimatedBudget.toLocaleString()} total)
              </div>
            </div>
          </div>
        </div>

        <Tabs defaultValue="deliverables" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-white mb-6 rounded-lg border border-[#E6E9F4]">
            <TabsTrigger
              value="chat"
              className="data-[state=active]:bg-[#2E3A8C] data-[state=active]:text-white"
            >
              Chat
            </TabsTrigger>
            <TabsTrigger
              value="deliverables"
              className="data-[state=active]:bg-[#2E3A8C] data-[state=active]:text-white"
            >
              Deliverables
            </TabsTrigger>
            <TabsTrigger
              value="activity"
              className="data-[state=active]:bg-[#2E3A8C] data-[state=active]:text-white"
            >
              Activity Log
            </TabsTrigger>
          </TabsList>

          <TabsContent value="chat">
            <ChatPanel 
              role="talent"
              messages={messages}
              setMessages={setMessages}
              onSend={(msg) => addActivityLogEntry(`Sent message: ${msg.slice(0, 50)}${msg.length > 50 ? '...' : ''}`)}
              partnerTypingLabel="Client is typing..."
              projectStatus={projectStatus}
              deliverables={deliverables}
            />
          </TabsContent>

          <TabsContent value="deliverables">
            <DeliverablesPanel 
              role="talent"
              deliverables={deliverables}
              editable
              showForm
              projectDeadline={projectDeadline}
              projectStartDate={projectStartDate}
              onAddDeliverable={addDeliverable}
              onStatusChange={updateDeliverableStatus}
              onUpdateDeliverable={updateDeliverable}
            />
          </TabsContent>

          <TabsContent value="activity">
            <ActivityLog
              role="talent"
              deliverables={deliverables}
              activityLog={activityLog}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}