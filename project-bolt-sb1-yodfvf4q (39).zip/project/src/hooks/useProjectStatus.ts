// useProjectStatus.ts
import { useState, useEffect, useCallback } from 'react';
import { mockDeliverables } from '@/data/mockDeliverables';

export interface Deliverable {
  id: string;
  title: string;
  description: string;
  problem?: string;
  kpis?: string[];
  status: 'recommended' | 'scoped' | 'in_progress' | 'approved' | 'performance_tracking';
  estimatedHours: number;
  actualHours: number;
  timeEntries: Array<{
    startTime: Date;
    endTime?: Date;
    hoursLogged?: number;
  }>;
  dueDate?: Date;
  files?: Array<{
    id: string;
    name: string;
    url: string;
    uploadedAt: Date;
  }>;
  isTracking?: boolean;
  currentSession?: {
    startTime: Date;
  };
}

const accessibleStatuses = ['Picked Up', 'Scope Defined', 'In Progress', 'Submitted', 'Revisions', 'Final Payment', 'Approved', 'Performance Tracking', 'Complete'];
const USE_MOCK_SESSION = true;

export function useProjectStatus(projectId?: string) {
  const [projectStatus, setProjectStatus] = useState<string>('Loading...');
  const [deliverables, setDeliverables] = useState<Deliverable[]>([]);
  const [activityLog, setActivityLog] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [hasTrackingInfo, setHasTrackingInfo] = useState(false);
  const [isArchived, setIsArchived] = useState(false);
  const [isAssignedToTalent, setIsAssignedToTalent] = useState(false);
  const [statusReady, setStatusReady] = useState(false);

  const calculateProjectStatus = useCallback(
    (items: Deliverable[], hasTracking: boolean, archived: boolean, assigned: boolean): string => {
      console.log('🔄 calculateProjectStatus called with:', {
        deliverablesCount: items.length,
        hasTracking,
        archived,
        assigned
      });

      if (!assigned) {
        console.log('⚠️ Project not assigned to talent – returning Live status');
        return 'Live';
      }

      if (items.length === 0) {
        console.log('✅ No deliverables found but project assigned – returning Picked Up status');
        return 'Picked Up';
      }

      const allApproved = items.every(d => d.status === 'approved' || d.status === 'performance_tracking');
      const anyInProgress = items.some(d => d.status === 'in_progress');
      const anyScoped = items.some(d => d.status === 'scoped');
      const anyRecommended = items.some(d => d.status === 'recommended');

      if (allApproved && hasTracking) return 'Complete';
      if (allApproved) return 'Approved';
      if (anyInProgress) return 'In Progress';
      if (anyScoped) return 'Scope Defined';
      if (anyRecommended) return 'Picked Up';
      return 'Picked Up';
    },
    []
  );

  // Load mock or real data
  useEffect(() => {
    if (USE_MOCK_SESSION) {
      console.log('✅ Using mock data path');
      
      // Add 2 deliverables to match project details
      const mockProjectDeliverables: Deliverable[] = [
        {
          id: '1',
          title: 'Technical SEO Audit',
          description: 'Complete site crawl and performance optimization recommendations including Core Web Vitals improvements',
          problem: 'Website has poor search visibility due to technical issues affecting crawlability and user experience metrics',
          kpis: [
            'Improve Core Web Vitals scores by 30%',
            'Fix 95% of critical SEO issues',
            'Increase search visibility by 20%',
            'Reduce page load time to under 3 seconds'
          ],
          status: 'recommended',
          estimatedHours: 8,
          actualHours: 0,
          timeEntries: [],
          dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000)
        },
        {
          id: '2',
          title: 'Content Strategy Development',
          description: 'Create comprehensive content calendar and distribution plan with focus on seasonal campaigns and evergreen content',
          problem: 'Current content lacks strategic direction and fails to engage target audience effectively, resulting in low conversion rates',
          kpis: [
            'Increase organic traffic by 25%',
            'Improve content engagement rate by 40%',
            'Generate 15+ qualified leads per month',
            'Achieve 4.5+ content quality score'
          ],
          status: 'recommended',
          estimatedHours: 8,
          actualHours: 0,
          timeEntries: [],
          dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
        }
      ];

      setDeliverables(mockProjectDeliverables);
      setIsAssignedToTalent(true);
      setIsArchived(false);
      setHasTrackingInfo(false);
      
      // Calculate status immediately with the mock data
      const calculatedStatus = calculateProjectStatus(
        mockProjectDeliverables,
        false, // hasTrackingInfo
        false, // isArchived
        true   // isAssignedToTalent
      );
      
      console.log('[✅ Immediate status calculation]', calculatedStatus);
      setProjectStatus(calculatedStatus);
      setStatusReady(true);
      setLoading(false);

      // Set activity log
      setActivityLog([
        'Project auction completed',
        'Project assigned to talent',
        `Project status updated to: ${calculatedStatus}`,
        'Talent recommended initial deliverables',
        'Client can now review and approve deliverable scope'
      ]);
    }
  }, [projectId, calculateProjectStatus]);

  const canAccess = statusReady && accessibleStatuses.includes(projectStatus);

  console.log('🔍 Access check:', {
    projectStatus,
    statusReady,
    canAccess,
    accessibleStatuses,
    statusInArray: accessibleStatuses.includes(projectStatus)
  });

  const updateDeliverableStatus = useCallback((id: string, newStatus: Deliverable['status']) => {
    setDeliverables(prev => {
      const updated = prev.map(d => d.id === id ? { ...d, status: newStatus } : d);
      
      // Recalculate status when deliverable status changes
      const newProjectStatus = calculateProjectStatus(
        updated,
        hasTrackingInfo,
        isArchived,
        isAssignedToTalent
      );
      setProjectStatus(newProjectStatus);
      
      return updated;
    });
    setActivityLog(prev => [...prev, `Deliverable status updated: ${newStatus}`]);
  }, [calculateProjectStatus, hasTrackingInfo, isArchived, isAssignedToTalent]);

  const addDeliverable = useCallback((deliverable: Partial<Deliverable>) => {
    const newDeliverable: Deliverable = {
      id: Date.now().toString(),
      title: deliverable.title || '',
      description: deliverable.description || '',
      problem: deliverable.problem || '',
      kpis: deliverable.kpis || [],
      status: 'recommended',
      estimatedHours: deliverable.estimatedHours || 0,
      actualHours: 0,
      timeEntries: [],
      ...deliverable
    };
    
    setDeliverables(prev => {
      const updated = [...prev, newDeliverable];
      
      // Recalculate status when new deliverable is added
      const newProjectStatus = calculateProjectStatus(
        updated,
        hasTrackingInfo,
        isArchived,
        isAssignedToTalent
      );
      setProjectStatus(newProjectStatus);
      
      return updated;
    });
    setActivityLog(prev => [...prev, `New deliverable added: ${newDeliverable.title}`]);
  }, [calculateProjectStatus, hasTrackingInfo, isArchived, isAssignedToTalent]);

  const updateDeliverable = useCallback((id: string, updates: Partial<Deliverable>) => {
    setDeliverables(prev => 
      prev.map(d => d.id === id ? { ...d, ...updates } : d)
    );
    setActivityLog(prev => [...prev, `Deliverable updated`]);
  }, []);

  const addActivityLogEntry = useCallback((message: string) => {
    setActivityLog(prev => [...prev, message]);
  }, []);

  const addTrackingInfo = useCallback((trackingData: any) => {
    setHasTrackingInfo(true);
    setActivityLog(prev => [...prev, 'Performance tracking information added']);
    
    // Recalculate status when tracking info is added
    const newProjectStatus = calculateProjectStatus(
      deliverables,
      true, // hasTrackingInfo is now true
      isArchived,
      isAssignedToTalent
    );
    setProjectStatus(newProjectStatus);
  }, [calculateProjectStatus, deliverables, isArchived, isAssignedToTalent]);

  const getApprovalProgress = useCallback(() => {
    const approvedCount = deliverables.filter(d => d.status === 'approved' || d.status === 'performance_tracking').length;
    const totalCount = deliverables.length;
    const percentage = totalCount > 0 ? Math.round((approvedCount / totalCount) * 100) : 0;
    return { approved: approvedCount, total: totalCount, percentage };
  }, [deliverables]);

  return {
    projectStatus,
    deliverables,
    activityLog,
    loading,
    statusReady,
    hasTrackingInfo,
    isArchived,
    isAssignedToTalent,
    canAccess,
    updateDeliverableStatus,
    addDeliverable,
    updateDeliverable,
    addActivityLogEntry,
    addTrackingInfo,
    getApprovalProgress
  };
}