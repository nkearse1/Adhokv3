// ChatPanel.tsx
import { useState } from 'react';
import { Send, Paperclip, Smile } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

interface Deliverable {
  id: string;
  title: string;
}

interface Message {
  id: string;
  text: string;
  sender: 'client' | 'talent';
  timestamp: Date;
  deliverableId?: string;
}

interface ChatPanelProps {
  role: 'client' | 'talent';
  messages: Message[];
  setMessages: (messages: Message[]) => void;
  onSend?: (message: string, deliverableId?: string) => void;
  partnerTypingLabel?: string;
  projectStatus: string;
  deliverables: Deliverable[];
}

const accessibleStatuses = ['In Progress', 'Scope Defined', 'Completed', 'Approved'];

export default function ChatPanel({ 
  role, 
  messages, 
  setMessages, 
  onSend,
  partnerTypingLabel = "Partner is typing...",
  projectStatus,
  deliverables
}: ChatPanelProps) {
  const [newMessage, setNewMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [selectedDeliverableId, setSelectedDeliverableId] = useState<string | null>(null);

  const canSendMessages = accessibleStatuses.includes(projectStatus);

  const handleSendMessage = () => {
    if (!newMessage.trim() || !canSendMessages) return;

    const message: Message = {
      id: Date.now().toString(),
      text: newMessage,
      sender: role,
      timestamp: new Date(),
      deliverableId: selectedDeliverableId || undefined
    };

    setMessages([...messages, message]);
    onSend?.(newMessage, selectedDeliverableId || undefined);
    setNewMessage('');

    // Simulate partner typing and response
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      const response: Message = {
        id: (Date.now() + 1).toString(),
        text: role === 'client' 
          ? "Thanks for the update! I'll review this and get back to you shortly."
          : "Understood. I'll make those adjustments and update you on the progress.",
        sender: role === 'client' ? 'talent' : 'client',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, response]);
    }, 2000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="bg-white border border-[#E6E9F4] rounded-lg h-[600px] flex flex-col">
      <div className="p-4 border-b border-[#E6E9F4]">
        <h3 className="font-semibold text-[#2E3A8C]">Project Chat</h3>
        <p className="text-sm text-gray-600">Status: <span className="font-medium">{projectStatus}</span></p>
      </div>

      {!canSendMessages && (
        <div className="bg-yellow-100 text-yellow-900 text-sm px-4 py-2 border-b border-yellow-300">
          Messaging is disabled until this project is actively in progress.
        </div>
      )}

      {deliverables.length > 0 && (
        <div className="p-2 border-b border-[#E6E9F4] flex gap-2 overflow-x-auto">
          <button
            onClick={() => setSelectedDeliverableId(null)}
            className={`px-3 py-1 rounded-full border ${!selectedDeliverableId ? 'bg-[#2E3A8C] text-white' : 'text-gray-700'}`}
          >
            General
          </button>
          {deliverables.map((d) => (
            <button
              key={d.id}
              onClick={() => setSelectedDeliverableId(d.id)}
              className={`px-3 py-1 rounded-full border ${selectedDeliverableId === d.id ? 'bg-[#2E3A8C] text-white' : 'text-gray-700'}`}
            >
              {d.title}
            </button>
          ))}
        </div>
      )}

      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.length === 0 ? (
            <div className="text-center text-gray-500 py-8">
              <p>No messages yet. Start the conversation!</p>
            </div>
          ) : (
            messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.sender === role ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`flex items-start gap-2 max-w-[70%] ${
                  message.sender === role ? 'flex-row-reverse' : 'flex-row'
                }`}>
                  <Avatar className="w-8 h-8">
                    <AvatarFallback className={
                      message.sender === 'client' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'
                    }>
                      {message.sender === 'client' ? 'C' : 'T'}
                    </AvatarFallback>
                  </Avatar>
                  <div className={`rounded-lg p-3 ${
                    message.sender === role
                      ? 'bg-[#2E3A8C] text-white'
                      : 'bg-gray-100 text-gray-900'
                  }`}>
                    {message.deliverableId && (
                      <p className="text-xs italic mb-1 text-gray-200">
                        Related to: {deliverables.find((d) => d.id === message.deliverableId)?.title || 'Unknown'}
                      </p>
                    )}
                    <p className="text-sm">{message.text}</p>
                    <p className={`text-xs mt-1 ${
                      message.sender === role ? 'text-blue-200' : 'text-gray-500'
                    }`}>
                      {message.timestamp.toLocaleTimeString([], { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </p>
                  </div>
                </div>
              </div>
            ))
          )}

          {isTyping && (
            <div className="flex justify-start">
              <div className="flex items-start gap-2">
                <Avatar className="w-8 h-8">
                  <AvatarFallback className={
                    role === 'client' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'
                  }>
                    {role === 'client' ? 'T' : 'C'}
                  </AvatarFallback>
                </Avatar>
                <div className="bg-gray-100 rounded-lg p-3">
                  <p className="text-sm text-gray-600 italic">{partnerTypingLabel}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </ScrollArea>

      <div className="p-4 border-t border-[#E6E9F4]">
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message..."
              disabled={!canSendMessages}
              className="pr-20"
            />
            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex gap-1">
              <Button variant="ghost" size="sm" className="h-6 w-6 p-0" disabled={!canSendMessages}>
                <Paperclip className="h-3 w-3" />
              </Button>
              <Button variant="ghost" size="sm" className="h-6 w-6 p-0" disabled={!canSendMessages}>
                <Smile className="h-3 w-3" />
              </Button>
            </div>
          </div>
          <Button 
            onClick={handleSendMessage}
            disabled={!newMessage.trim() || !canSendMessages}
            className="bg-[#2E3A8C] hover:bg-[#1B276F]"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
