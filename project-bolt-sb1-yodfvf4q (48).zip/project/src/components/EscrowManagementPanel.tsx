import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  CreditCard, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  Flag
} from 'lucide-react';
import { toast } from 'sonner';

interface EscrowManagementPanelProps {
  projects?: any[];
}

export default function EscrowManagementPanel({ projects = [] }: EscrowManagementPanelProps) {
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [flagReason, setFlagReason] = useState("");

  const handleFlagProject = () => {
    if (!flagReason.trim()) {
      toast.error('Please provide a reason for flagging');
      return;
    }
    
    toast.success('Project flagged for review');
    setFlagReason("");
  };

  const handleOverrideEscrow = (action: 'release' | 'cancel') => {
    if (action === 'release') {
      toast.success('Admin override: Payment released');
    } else {
      toast.error('Admin override: Escrow cancelled');
    }
  };

  return (
    <Card>
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold mb-4">Escrow Management</h3>
        <p className="text-gray-600 mb-4">
          Select a project to manage its escrow status and override payments if necessary.
        </p>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Select Project
            </label>
            <select
              value={selectedProjectId || ''}
              onChange={(e) => setSelectedProjectId(e.target.value || null)}
              className="w-full p-2 border border-gray-300 rounded-md"
            >
              <option value="">Choose a project...</option>
              {projects.map((project) => (
                <option key={project.id} value={project.id}>
                  {project.title} - {project.status}
                  {project.flagged ? ' (FLAGGED)' : ''}
                </option>
              ))}
            </select>
          </div>

          {selectedProjectId && (
            <div className="border-t pt-4 space-y-6">
              <div className="flex items-center gap-4 mb-4">
                <Badge variant="outline" className="text-sm">
                  Escrow Status: pending
                </Badge>
                {projects.find(p => p.id === selectedProjectId)?.flagged && (
                  <Badge variant="destructive" className="text-sm">
                    Project Flagged
                  </Badge>
                )}
              </div>

              {/* Fraud Prevention Section */}
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Flag className="w-4 h-4 text-red-600" />
                  <h4 className="font-medium text-red-900">Fraud Prevention</h4>
                </div>
                <p className="text-sm text-red-800 mb-3">
                  Flag this project for review to freeze payments and restrict actions.
                </p>
                <div className="flex gap-2">
                  <Input
                    placeholder="Reason for flagging..."
                    value={flagReason}
                    onChange={(e) => setFlagReason(e.target.value)}
                    className="flex-1"
                  />
                  <Button 
                    onClick={handleFlagProject}
                    variant="destructive"
                    disabled={!flagReason.trim()}
                  >
                    <Flag className="w-4 h-4 mr-2" />
                    Flag Project
                  </Button>
                </div>
              </div>

              {/* Admin Override Controls */}
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="w-4 h-4 text-yellow-600" />
                  <h4 className="font-medium text-yellow-900">Admin Override Controls</h4>
                </div>
                <p className="text-sm text-yellow-800 mb-3">
                  Use these controls carefully. They bypass normal approval processes.
                </p>
                <div className="flex gap-2">
                  <Button 
                    onClick={() => handleOverrideEscrow('release')}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <CreditCard className="w-4 h-4 mr-2" />
                    Force Release
                  </Button>
                  <Button 
                    onClick={() => handleOverrideEscrow('cancel')}
                    variant="destructive"
                  >
                    <XCircle className="w-4 h-4 mr-2" />
                    Cancel Escrow
                  </Button>
                </div>
              </div>

              {/* Pending Approval Section */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-medium text-blue-900 mb-2">Pending Approval</h4>
                <p className="text-sm text-blue-800 mb-3">
                  This escrow release is awaiting client approval. You can override if necessary.
                </p>
                <div className="flex gap-2">
                  <Button size="sm">
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Admin Approve
                  </Button>
                  <Button variant="outline" size="sm">
                    <XCircle className="w-4 h-4 mr-2" />
                    Admin Reject
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}