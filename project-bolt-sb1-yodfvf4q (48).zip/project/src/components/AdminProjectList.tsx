import React, { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/lib/supabaseClient";
import { toast } from "sonner";
import {
  User as UserIcon,
  Mail as MailIcon,
  MapPin as MapPinIcon,
  Briefcase as BriefcaseIcon,
  Link as LinkIcon,
  CheckCircle as CheckCircleIcon,
  XCircle as XCircleIcon,
  Search as SearchIcon,
  ChevronLeft as ChevronLeftIcon,
  ChevronRight as ChevronRightIcon,
} from "lucide-react";
// Renaming imported component to prevent conflict

const MOCK_PROJECTS = [
  {
    id: "proj-001",
    title: "SEO Overhaul for Startup",
    description: "Complete on-page and technical SEO for a VC-backed SaaS startup.",
    status: "in_progress",
    deadline: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
    project_bids: [{ id: "bid-1" }, { id: "bid-2" }],
    chatCount: 3,
    metadata: {
      marketing: {
        budget: 3000,
      },
    },
  },
  {
    id: "proj-002",
    title: "Landing Page Optimization",
    description: "Design and optimize a high-conversion landing page for Google Ads.",
    status: "completed",
    deadline: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    project_bids: [{ id: "bid-3" }],
    chatCount: 1,
    metadata: {
      marketing: {
        budget: 1200,
      },
    },
  },
  {
    id: "proj-003",
    title: "Blog Strategy Buildout",
    description: "Develop content strategy and create 10 pillar blog posts.",
    status: "open",
    deadline: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString(),
    project_bids: [],
    chatCount: 0,
    metadata: {
      marketing: {
        budget: 5000,
      },
    },
  },
];

interface TalentProfile {
  id: string;
  full_name: string;
  email: string;
  phone: string;
  location: string;
  linkedin: string;
  portfolio: string;
  bio: string;
  expertise: string;
  resume_url: string;
  created_at: string;
  is_qualified: boolean;
}

const ITEMS_PER_PAGE = 5;

export function AdminTalentList() {
  const [talents, setTalents] = useState<TalentProfile[]>([
    {
      id: "1",
      full_name: "Jane Doe",
      email: "jane.doe@example.com",
      phone: "123-456-7890",
      location: "New York, NY",
      linkedin: "https://linkedin.com/in/janedoe",
      portfolio: "https://janedoe.dev",
      bio: "SEO expert with 5 years of experience",
      expertise: "SEO",
      resume_url: "resume_jane_doe.pdf",
      created_at: new Date().toISOString(),
      is_qualified: true,
    },
    {
      id: "2",
      full_name: "John Smith",
      email: "john.smith@example.com",
      phone: "987-654-3210",
      location: "San Francisco, CA",
      linkedin: "https://linkedin.com/in/johnsmith",
      portfolio: "https://johnsmith.work",
      bio: "Full-stack developer and consultant",
      expertise: "Web Development",
      resume_url: "resume_john_smith.pdf",
      created_at: new Date().toISOString(),
      is_qualified: false,
    },
  ]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [qualificationFilter, setQualificationFilter] = useState<string>("all");

  // useEffect(() => {
//   fetchTalents();
// }, [currentPage, debouncedSearch, qualificationFilter]);

  const fetchTalents = async () => {
    try {
      setLoading(true);
      let query = supabase.from("talent_profiles").select("count", { count: "exact" });
      if (debouncedSearch) {
        query = query.or(`full_name.ilike.%${debouncedSearch}%,email.ilike.%${debouncedSearch}%,expertise.ilike.%${debouncedSearch}%`);
      }
      if (qualificationFilter !== "all") {
        query = query.eq("is_qualified", qualificationFilter === "qualified");
      }
      const { count, error: countError } = await query;
      if (countError) throw countError;
      setTotalCount(count || 0);

      let dataQuery = supabase
        .from("talent_profiles")
        .select("*")
        .order("created_at", { ascending: false })
        .range((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE - 1);

      if (debouncedSearch) {
        dataQuery = dataQuery.or(`full_name.ilike.%${debouncedSearch}%,email.ilike.%${debouncedSearch}%,expertise.ilike.%${debouncedSearch}%`);
      }
      if (qualificationFilter !== "all") {
        dataQuery = dataQuery.eq("is_qualified", qualificationFilter === "qualified");
      }
      const { data, error } = await dataQuery;
      if (error) throw error;
      setTalents(data || []);
    } catch (error) {
      console.error("Error:", error);
      toast.error("Failed to fetch talent profiles");
    } finally {
      setLoading(false);
    }
  };

  const toggleQualification = async (talentId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from("talent_profiles")
        .update({ is_qualified: !currentStatus })
        .eq("id", talentId);
      if (error) throw error;
      setTalents(talents.map(talent => talent.id === talentId ? { ...talent, is_qualified: !currentStatus } : talent));
      toast.success(`Talent ${!currentStatus ? "qualified" : "disqualified"} successfully`);
    } catch (error) {
      console.error("Error:", error);
      toast.error("Failed to update qualification status");
    }
  };

  const getResumeUrl = (resumeUrl: string) => {
    if (!resumeUrl) return null;
    if (resumeUrl.startsWith("http")) return resumeUrl;
    const { data } = supabase.storage.from("resumes").getPublicUrl(resumeUrl);
    return data.publicUrl;
  };

  const totalPages = Math.ceil(totalCount / ITEMS_PER_PAGE);
  if (loading && !talents.length) return <div className="text-center py-8">Loading talent profiles...</div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:justify-between sm:items-center">
        <h2 className="text-3xl font-bold">Talent Profiles</h2>
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
          <div className="relative w-full sm:w-auto">
            <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input type="text" placeholder="Search talents..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-9 w-full sm:w-[300px]" />
          </div>
          <Select value={qualificationFilter} onValueChange={setQualificationFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Profiles</SelectItem>
              <SelectItem value="qualified">Qualified</SelectItem>
              <SelectItem value="unqualified">Unqualified</SelectItem>
            </SelectContent>
          </Select>
          <Badge variant="secondary" className="text-sm whitespace-nowrap">{totalCount} Total</Badge>
        </div>
      </div>

      {talents.length === 0 ? (
        <Card>
          <CardContent className="p-6 text-center text-gray-500">
            {debouncedSearch || qualificationFilter !== "all"
              ? "No matching talent profiles found"
              : "No talent profiles found"}
          </CardContent>
        </Card>
      ) : (
        <>
          <Card>
            <CardContent className="p-0 overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Expertise</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Qualified</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {talents.map((talent) => (
                    <TableRow key={talent.id}>
                      <TableCell className="font-medium flex items-center gap-2">
                        <UserIcon className="h-4 w-4 text-gray-500" />
                        {talent.full_name}
                      </TableCell>
                      <TableCell>
                        <a href={`mailto:${talent.email}`} className="text-blue-600 hover:underline">
                          {talent.email}
                        </a>
                      </TableCell>
                      <TableCell>{talent.expertise}</TableCell>
                      <TableCell>{talent.location || "-"}</TableCell>
                      <TableCell>
                        <Badge variant={talent.is_qualified ? "success" : "secondary"}>
                          {talent.is_qualified ? "Qualified" : "Unqualified"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant={talent.is_qualified ? "destructive" : "default"}
                            onClick={() => toggleQualification(talent.id, talent.is_qualified)}
                            className="flex items-center gap-1"
                          >
                            {talent.is_qualified ? (
                              <>
                                <XCircleIcon className="h-4 w-4" />
                                Disqualify
                              </>
                            ) : (
                              <>
                                <CheckCircleIcon className="h-4 w-4" />
                                Qualify
                              </>
                            )}
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => toast.info("Feature coming soon")}
                          >
                            View
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {totalPages > 1 && (
            <div className="flex items-center justify-between pt-4">
              <Button
                variant="outline"
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="flex items-center gap-2"
              >
                <ChevronLeftIcon className="h-4 w-4" />
                Previous
              </Button>
              <span className="text-sm text-gray-600">
                Page {currentPage} of {totalPages}
              </span>
              <Button
                variant="outline"
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="flex items-center gap-2"
              >
                Next
                <ChevronRightIcon className="h-4 w-4" />
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

// Using existing React import
export default function AdminProjectList() {
  const [projects] = useState(MOCK_PROJECTS);

  if (!projects.length) {
    return (
      <Card>
        <CardContent className="p-6 text-center text-gray-500">
          No projects found
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="p-0 overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Title</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Bids</TableHead>
              <TableHead>Deadline</TableHead>
              <TableHead>Description</TableHead>
              <TableHead>UUID</TableHead>
              <TableHead>Total Revenue</TableHead>
              <TableHead>Platform Revenue</TableHead>
              <TableHead>Chats</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {projects.map((project) => (
              <TableRow key={project.id}>
                <TableCell className="font-medium">{project.title}</TableCell>
                <TableCell>
                  <Badge variant="secondary">{project.status}</Badge>
                </TableCell>
                <TableCell>{project.project_bids?.length || 0}</TableCell>
                <TableCell>{project.deadline}</TableCell>
                <TableCell className="max-w-[250px] truncate">{project.description}</TableCell>
                <TableCell className="text-xs font-mono">{project.id}</TableCell>
                <TableCell>
                  ${project.metadata?.marketing?.budget?.toLocaleString() || 0}
                </TableCell>
                <TableCell>
                  ${(project.metadata?.marketing?.budget * 0.1).toLocaleString() || 0}
                </TableCell>
                <TableCell>{project.chatCount}</TableCell>
                <TableCell>
                  <Button size="sm" variant="outline">
                    View
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}


