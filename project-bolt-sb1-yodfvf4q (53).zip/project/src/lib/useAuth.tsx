import { useState, useEffect } from 'react';
import { supabase } from '@supabase/supabaseClient';

type UserRole = 'admin' | 'client' | 'talent' | null;

interface AuthState {
  authUser: any | null;
  userId: string | null;
  userRole: UserRole;
  isAuthenticated: boolean;
  isAdmin: boolean;
  loading: boolean;
}

const USE_MOCK_SESSION = true;
const MOCK_EXPERTISE_LEVEL: 'Specialist' | 'Pro Talent' | 'Expert' = 'Expert';

function getMockUser(
  level: 'Specialist' | 'Pro Talent' | 'Expert' = 'Expert',
  role: UserRole = 'talent'
) {
  if (role === 'client') {
    return {
      id: 'mock-client-id',
      email: 'client@adhok.dev',
      user_metadata: {
        full_name: 'Mock Client User',
        user_role: 'client'
      },
      app_metadata: {
        user_role: 'client'
      }
    };
  }

  if (role === 'admin') {
    return {
      id: 'mock-admin-id',
      email: 'admin@adhok.dev',
      user_metadata: {
        full_name: 'Mock Admin User',
        user_role: 'admin'
      },
      app_metadata: {
        user_role: 'admin'
      }
    };
  }

  return {
    id: 'mock-talent-id',
    email: 'talent@adhok.dev',
    user_metadata: {
      full_name: `Mock ${level} User`,
      user_role: 'talent',
      marketing: {
        expertiseLevel: level
      }
    },
    app_metadata: {
      user_role: 'talent'
    }
  };
}

export function useAuth(): AuthState {
  const [authUser, setAuthUser] = useState<any | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  const loadSession = async () => {
    setLoading(true);

    if (USE_MOCK_SESSION) {
      const stored = localStorage.getItem('mockUser');
      const parsed = stored ? JSON.parse(stored) : null;
      const storedRole: UserRole = parsed?.app_metadata?.user_role || parsed?.user_metadata?.user_role || 'talent';
      const user = parsed || getMockUser(MOCK_EXPERTISE_LEVEL, storedRole);

      if (!parsed) {
        localStorage.setItem('mockUser', JSON.stringify(user));
      }

      setAuthUser(user);
      setUserId(user.id);
      const role = user.app_metadata?.user_role || user.user_metadata?.user_role as UserRole;
      setUserRole(role);
      setIsAuthenticated(true);
      setIsAdmin(role === 'admin');
      setLoading(false);
      return;
    }

    const { data: { session }, error } = await supabase.auth.getSession();
    if (error || !session?.user) {
      setAuthUser(null);
      setIsAuthenticated(false);
      setUserId(null);
      setUserRole(null);
      setIsAdmin(false);
      setLoading(false);
      return;
    }

    const user = session.user;
    setAuthUser(user);
    setUserId(user.id);
    const role = user.app_metadata?.user_role || user.user_metadata?.user_role as UserRole;
    setUserRole(role);
    setIsAuthenticated(true);
    setIsAdmin(role === 'admin');
    setLoading(false);
  };

  useEffect(() => {
    loadSession();

    const handleMockRoleChange = () => loadSession();
    window.addEventListener('mock-role-changed', handleMockRoleChange);

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!USE_MOCK_SESSION && session?.user) {
        loadSession();
      }
    });

    return () => {
      subscription.unsubscribe();
      window.removeEventListener('mock-role-changed', handleMockRoleChange);
    };
  }, []);

  return {
    authUser,
    userId,
    userRole,
    isAuthenticated,
    isAdmin,
    loading,
  };
}