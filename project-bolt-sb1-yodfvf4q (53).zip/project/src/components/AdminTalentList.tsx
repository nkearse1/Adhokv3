import React, { useEffect, useRef, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@supabase/supabaseClient";
import { toast } from "sonner";
import {
  User as UserIcon,
  Mail as MailIcon,
  MapPin as MapPinIcon,
  Briefcase as BriefcaseIcon,
  Link as LinkIcon,
  CheckCircle as CheckCircleIcon,
  XCircle as XCircleIcon,
  Search as SearchIcon,
  ChevronLeft as ChevronLeftIcon,
  ChevronRight as ChevronRightIcon,
  Upload as UploadIcon,
} from "lucide-react";
import { applyAutoQualification } from '@/lib/qualificationUtils';

const ITEMS_PER_PAGE = 5;

interface TalentProfile {
  id: string;
  full_name: string;
  email: string;
  phone: string;
  location: string;
  linkedin: string;
  portfolio: string;
  bio: string;
  expertise: string;
  resume_url: string;
  created_at: string;
  is_qualified: boolean;
  join_method?: string;
}

export default function AdminTalentList() {
  const [talents, setTalents] = useState<TalentProfile[]>([]);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [qualificationFilter, setQualificationFilter] = useState<string>("all");
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const navigate = useNavigate();

  const handleBulkQualify = async () => {
    try {
      const { error } = await supabase
        .from("talent_profiles")
        .update({ is_qualified: true })
        .in("id", selectedIds);
      if (error) throw error;
      toast.success(`Qualified ${selectedIds.length} talents.`);
      setSelectedIds([]);
      fetchTalents();
    } catch (error) {
      toast.error("Failed bulk qualification");
    }
  };

  const toggleSelect = (id: string) => {
    setSelectedIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const toggleSelectAll = () => {
    if (selectedIds.length === talents.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(talents.map(t => t.id));
    }
  };

  const fetchTalents = async () => {
    try {
      setLoading(true);
      let query = supabase.from("talent_profiles").select("count", { count: "exact" });
      if (debouncedSearch) {
        query = query.or(`full_name.ilike.%${debouncedSearch}%,email.ilike.%${debouncedSearch}%,expertise.ilike.%${debouncedSearch}%`);
      }
      if (qualificationFilter !== "all") {
        query = query.eq("is_qualified", qualificationFilter === "qualified");
      }
      const { count, error: countError } = await query;
      if (countError) throw countError;
      setTotalCount(count || 0);

      let dataQuery = supabase
        .from("talent_profiles")
        .select("*")
        .order("created_at", { ascending: false })
        .range((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE - 1);

      if (debouncedSearch) {
        dataQuery = dataQuery.or(`full_name.ilike.%${debouncedSearch}%,email.ilike.%${debouncedSearch}%,expertise.ilike.%${debouncedSearch}%`);
      }
      if (qualificationFilter !== "all") {
        dataQuery = dataQuery.eq("is_qualified", qualificationFilter === "qualified");
      }
      const { data, error } = await dataQuery;
      if (error) throw error;

      const qualifiedWithLogic = await applyAutoQualification(data || []);
      setTalents(qualifiedWithLogic);
    } catch (error) {
      console.error("Error:", error);
      toast.error("Failed to fetch talent profiles");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTalents();
  }, [currentPage, debouncedSearch, qualificationFilter]);

  const totalPages = Math.ceil(totalCount / ITEMS_PER_PAGE);
  if (loading && !talents.length) return <div className="text-center py-8">Loading talent profiles...</div>;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold">Talent Profiles</h2>
        {selectedIds.length > 0 && (
          <div className="flex gap-2">
            <Button onClick={handleBulkQualify}>Bulk Qualify</Button>
          </div>
        )}
      </div>

      <Card>
        <CardContent className="p-0 overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>
                  <input
                    type="checkbox"
                    checked={selectedIds.length === talents.length}
                    onChange={toggleSelectAll}
                  />
                </TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Expertise</TableHead>
                <TableHead>Location</TableHead>
                <TableHead>Qualified</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {talents.map((talent) => (
                <TableRow key={talent.id}>
                  <TableCell>
                    <input
                      type="checkbox"
                      checked={selectedIds.includes(talent.id)}
                      onChange={() => toggleSelect(talent.id)}
                    />
                  </TableCell>
                  <TableCell>{talent.full_name}</TableCell>
                  <TableCell>{talent.email}</TableCell>
                  <TableCell>{talent.expertise}</TableCell>
                  <TableCell>{talent.location}</TableCell>
                  <TableCell>
                    <Badge variant={talent.is_qualified ? "success" : "secondary"}>
                      {talent.is_qualified ? "Qualified" : "Unqualified"}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}