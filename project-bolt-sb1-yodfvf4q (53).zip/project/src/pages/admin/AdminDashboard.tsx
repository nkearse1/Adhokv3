// AdminDashboard.tsx
import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Users, Flag, Briefcase, DollarSign, ThumbsDown } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import AdminTalentList from '@/components/AdminTalentList';
import AdminProjectList from '@/components/AdminProjectList';
import RevenuePanel from '@/components/RevenuePanel';
import AdminClientList from '@/components/AdminClientList';
import AdminAlerts from '@/components/AdminAlerts'; // <- Needed

const metrics = [
  { key: 'totalProjects', label: 'Total Projects', icon: Briefcase, color: 'bg-blue-100', value: 1 },
  { key: 'activeTalents', label: 'Active Talents', icon: Users, color: 'bg-green-100', value: 1 },
  { key: 'flaggedProjects', label: 'Flagged Projects', icon: Flag, color: 'bg-red-100', value: 0 },
  { key: 'estRevenue', label: 'Est. Revenue', icon: DollarSign, color: 'bg-yellow-100', value: 4200 },
  { key: 'revPerTalent', label: 'Rev. per Active Talent', icon: DollarSign, color: 'bg-purple-100', value: 4200 },
  { key: 'negReviews', label: 'Negative Reviews', icon: ThumbsDown, color: 'bg-pink-100', value: 2 }
];

const chartData = [
  { time: 'Week 1', totalProjects: 1, estRevenue: 1500, activeTalents: 1, revPerTalent: 1500, flaggedProjects: 0, negReviews: 0 },
  { time: 'Week 2', totalProjects: 2, estRevenue: 3000, activeTalents: 1, revPerTalent: 3000, flaggedProjects: 0, negReviews: 1 },
  { time: 'Week 3', totalProjects: 3, estRevenue: 4200, activeTalents: 1, revPerTalent: 4200, flaggedProjects: 1, negReviews: 2 }
];

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('alerts');
  const [activeLines, setActiveLines] = useState<string[]>(['totalProjects', 'activeTalents']);

  const toggleLine = (key: string) => {
    setActiveLines((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]
    );
  };

  return (
    <div className="max-w-6xl mx-auto p-4 sm:p-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <h1 className="text-2xl sm:text-3xl font-bold text-[#2E3A8C]">Admin Dashboard</h1>
        <Button className="w-full sm:w-auto">New Project</Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="alerts">Alerts</TabsTrigger>
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
          <TabsTrigger value="talent">Talent</TabsTrigger>
          <TabsTrigger value="clients">Clients</TabsTrigger>
        </TabsList>

        <TabsContent value="alerts">
          <AdminAlerts />
        </TabsContent>

        <TabsContent value="revenue">
          <RevenuePanel />
        </TabsContent>

        <TabsContent value="talent">
          <AdminTalentList />
        </TabsContent>

        <TabsContent value="clients">
          <AdminClientList />
        </TabsContent>
      </Tabs>
    </div>
  );
}
