// vite.config.ts
import path from 'path';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: [
      { find: '@',               replacement: path.resolve(__dirname, 'src') },
      { find: '@supabase',       replacement: path.resolve(__dirname, 'supabase') },
      // optional: if you still import directly from '@supabase/supabaseClient'
      { find: '@supabase/supabaseClient',
        replacement: path.resolve(__dirname, 'supabase', 'supabaseClient.ts') },
    ],
  },

  optimizeDeps: { exclude: ['lucide-react'] },
  server: { /* your proxy/historyApiFallback */ },
  build: {
    rollupOptions: {
      output: { manualChunks: { vendor: ['react','react-dom','react-router-dom'] } },
    },
  },
  base: './',
})
