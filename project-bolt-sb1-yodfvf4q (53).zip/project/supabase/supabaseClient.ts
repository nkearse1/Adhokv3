// supabase/supabaseClient.ts
import { createClient } from '@supabase/supabase-js';
import { SUPABASE_URL, SUPABASE_ANON_KEY } from '@supabase/supabaseConfig';

export const supabase = createClient(
  SUPABASE_URL,
  SUPABASE_ANON_KEY,
  {
    auth: {
      persistSession: true,
      storageKey:     'adhok_auth',
      autoRefreshToken: true,
      detectSessionInUrl: true,
      flowType: 'pkce',
    },
  }
);

// Optional: expose to window for debugging
if (typeof window !== 'undefined') {
  (window as any).supabase = supabase;
}

/**
 * Optional helper to make direct Supabase REST requests with logging.
 */
export async function fetchWithSupabase(url: string, options?: RequestInit) {
  const response = await fetch(url, options);
  if (!response.ok) {
    let errorBody = {};
    try {
      errorBody = await response.json();
    } catch (_) {
      errorBody = { message: 'Could not parse error JSON' };
    }

    console.error('Supabase request failed', {
      status: response.status,
      statusText: response.statusText,
      error: errorBody,
    });
  }
  return response;
}
