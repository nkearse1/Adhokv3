import React from 'react'

interface ProjectTimelineProps {
  status: string
}

const steps = [
  'Draft',
  'Live',
  'Picked Up',
  'Initial Payment',
  'Scope Defined',
  'Submitted',
  'Draft Payment',
  'Revisions',
  'Approved',
  'Final Payment',
  'Completed'
]

// Guidance on what is required to move from the current step to the next one
const stepActions: Record<string, string> = {
  Draft: 'Publish your project to make it visible to experts.',
  Live: 'Await a qualified expert to pick up the project.',
  'Picked Up': 'Send the initial payment to kick things off.',
  'Initial Payment': 'Define the project scope with your expert.',
  'Scope Defined': 'Let the expert work and submit deliverables.',
  Submitted: 'Review the work and send the draft payment.',
  'Draft Payment': 'Request any revisions if necessary.',
  Revisions: 'Approve the work when you are satisfied.',
  Approved: 'Send the final payment to close out.',
  'Final Payment': 'Project will be marked as completed.',
}

export default function ProjectTimeline({ status }: ProjectTimelineProps) {
  const currentIndex = steps.indexOf(status)
  const nextStep = steps[currentIndex + 1]

  const actionText = stepActions[status]

  return (
    <div className="w-full overflow-x-auto">
      <div className="flex items-center justify-between space-x-2">
        {steps.map((step, idx) => {
          const isComplete = idx < currentIndex
          const isCurrent = idx === currentIndex
          const isPayment = step.includes('Payment')
          return (
            <div key={step} className="flex-1 min-w-[80px] text-center">
              <div
                className={`mx-auto mb-1 h-8 w-8 rounded-full flex items-center justify-center text-sm font-bold ${
                  isComplete
                    ? isPayment 
                      ? 'bg-[#00A499] text-white'
                      : 'bg-[#00A499] text-white'
                    : isCurrent
                    ? isPayment
                      ? 'bg-[#00A499] text-white'
                      : 'bg-[#2E3A8C] text-white'
                    : 'bg-gray-200 text-gray-600'
                }`}
              >
                {idx + 1}
              </div>
              <p className={`text-xs ${isCurrent ? 'font-semibold text-[#2E3A8C]' : 'text-gray-600'}`}>
                {step}
              </p>
            </div>
          )
        })}
      </div>
      {nextStep && (
        <div className="mt-3 text-center">
          <p className="text-sm font-medium text-gray-700">Next: {nextStep}</p>
          {actionText && (
            <p className="text-xs text-gray-500">{actionText}</p>
          )}
        </div>
      )}
    </div>
  )
}