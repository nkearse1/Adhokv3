import React, { useState } from 'react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Clock, Upload, FileText, ExternalLink, Trash2, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';
import KanbanBoard from '@/components/KanbanBoard';
import { toast } from 'sonner';

interface TimeEntry {
  startTime: Date;
  endTime?: Date;
  hoursLogged?: number;
}

export interface Deliverable {
  id: string;
  title: string;
  description: string;
  status: 'recommended' | 'scoped' | 'in_progress' | 'approved' | 'completed';
  estimatedHours: number;
  actualHours: number;
  timeEntries: TimeEntry[];
  dueDate?: Date;
  files?: Array<{
    id: string;
    name: string;
    url: string;
    uploadedAt: Date;
  }>;
  isTracking?: boolean;
  currentSession?: {
    startTime: Date;
  };
}

interface DeliverablesPanelProps {
  role: 'talent' | 'client' | 'admin';
  deliverables?: Deliverable[];
  projectStartDate: Date;
  projectDeadline: Date;
  editable?: boolean;
  showForm?: boolean;
  onAddDeliverable?: (d: Partial<Deliverable>) => void;
  onStatusChange?: (id: string, newStatus: Deliverable['status']) => void;
  onUpdateDeliverable?: (id: string, updates: Partial<Deliverable>) => void;
}

export default function DeliverablesPanel({
  role,
  deliverables = [],
  projectStartDate,
  projectDeadline,
  editable = false,
  showForm = false,
  onAddDeliverable,
  onStatusChange,
  onUpdateDeliverable
}: DeliverablesPanelProps) {
  const [newDeliverable, setNewDeliverable] = useState({
    title: '',
    description: '',
    estimatedHours: 0
  });

  const handleAdd = () => {
    if (!newDeliverable.title || !newDeliverable.description || !newDeliverable.estimatedHours) {
      toast.error('Please fill in all fields');
      return;
    }

    const deliverable = {
      id: Date.now().toString(),
      ...newDeliverable,
      status: 'recommended' as const
    };

    onAddDeliverable?.(deliverable);
    setNewDeliverable({ title: '', description: '', estimatedHours: 0 });
    toast.success('Recommendation added successfully');
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, deliverableId: string) => {
    const files = e.target.files;
    if (!files?.length) return;

    const deliverable = deliverables.find(d => d.id === deliverableId);
    if (!deliverable || deliverable.status !== 'in_progress') {
      toast.error('Files can only be uploaded for in-progress deliverables');
      return;
    }

    // Simulated file upload - in production, this would upload to your storage
    const newFiles = Array.from(files).map(file => ({
      id: Date.now().toString(),
      name: file.name,
      url: URL.createObjectURL(file),
      uploadedAt: new Date()
    }));

    const updatedFiles = [...(deliverable.files || []), ...newFiles];
    onUpdateDeliverable?.(deliverableId, { files: updatedFiles });
    toast.success('Files uploaded successfully');
  };

  const handleDeleteFile = (deliverableId: string, fileId: string) => {
    const deliverable = deliverables.find(d => d.id === deliverableId);
    if (!deliverable) return;

    const updatedFiles = deliverable.files?.filter(f => f.id !== fileId) || [];
    onUpdateDeliverable?.(deliverableId, { files: updatedFiles });
    toast.success('File removed');
  };

  const inProgressDeliverables = deliverables.filter(d => d.status === 'in_progress');

  return (
    <div className="bg-white border border-[#E6E9F4] rounded-lg p-6 shadow-sm">
      <Tabs defaultValue="kanban">
        <TabsList className="mb-6 bg-white border rounded-lg">
          <TabsTrigger value="kanban" className="data-[state=active]:bg-[#2E3A8C] data-[state=active]:text-white">
            Kanban
          </TabsTrigger>
          {editable && showForm && (
            <TabsTrigger value="recommend" className="data-[state=active]:bg-[#2E3A8C] data-[state=active]:text-white">
              Recommend
            </TabsTrigger>
          )}
          <TabsTrigger value="files" className="data-[state=active]:bg-[#2E3A8C] data-[state=active]:text-white">
            Files
          </TabsTrigger>
        </TabsList>

        <TabsContent value="kanban">
          <KanbanBoard
            deliverables={deliverables}
            projectStartDate={projectStartDate}
            projectDeadline={projectDeadline}
            onStatusChange={onStatusChange}
          />
        </TabsContent>

        {editable && showForm && (
          <TabsContent value="recommend">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Deliverable title</label>
                <Input
                  value={newDeliverable.title}
                  onChange={(e) => setNewDeliverable({ ...newDeliverable, title: e.target.value })}
                  placeholder="Enter title"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Detailed description</label>
                <Textarea
                  value={newDeliverable.description}
                  onChange={(e) => setNewDeliverable({ ...newDeliverable, description: e.target.value })}
                  placeholder="Describe the deliverable"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Estimated hours</label>
                <Input
                  type="number"
                  min="0"
                  value={newDeliverable.estimatedHours}
                  onChange={(e) => setNewDeliverable({ ...newDeliverable, estimatedHours: parseInt(e.target.value) || 0 })}
                />
              </div>
              <Button onClick={handleAdd} className="bg-[#00A499] hover:bg-[#00A499]/90">
                Submit Recommendation
              </Button>
            </div>
          </TabsContent>
        )}

        <TabsContent value="files">
          <div className="space-y-6">
            <h3 className="text-lg font-semibold">Project Files</h3>

            {inProgressDeliverables.length === 0 ? (
              <div className="text-center py-8 bg-yellow-50 rounded-lg border border-yellow-200">
                <AlertCircle className="w-12 h-12 mx-auto mb-3 text-yellow-500" />
                <p className="text-yellow-700 font-medium">No In-Progress Deliverables</p>
                <p className="text-sm text-yellow-600">Move deliverables to "In Progress" to upload files</p>
              </div>
            ) : (
              inProgressDeliverables.map(deliverable => (
                <div key={deliverable.id} className="border rounded-lg p-4">
                  <div className="flex justify-between items-start mb-4">
                    <h4 className="font-medium">{deliverable.title}</h4>
                    <div>
                      <Input
                        type="file"
                        className="hidden"
                        id={`file-upload-${deliverable.id}`}
                        multiple
                        onChange={(e) => handleFileUpload(e, deliverable.id)}
                        accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.zip,.rar"
                      />
                      <Button
                        onClick={() => document.getElementById(`file-upload-${deliverable.id}`)?.click()}
                        className="bg-[#00A499] hover:bg-[#00A499]/90"
                      >
                        <Upload className="w-4 h-4 mr-2" />
                        Upload Files
                      </Button>
                    </div>
                  </div>

                  {(!deliverable.files || deliverable.files.length === 0) ? (
                    <p className="text-gray-500 text-sm">No files uploaded for this deliverable</p>
                  ) : (
                    <div className="space-y-2">
                      {deliverable.files.map(file => (
                        <div
                          key={file.id}
                          className="flex items-center justify-between p-2 bg-gray-50 rounded"
                        >
                          <div className="flex items-center gap-3">
                            <FileText className="w-4 h-4 text-gray-400" />
                            <div>
                              <p className="text-sm font-medium">{file.name}</p>
                              <p className="text-xs text-gray-500">
                                Uploaded {format(file.uploadedAt, 'MMM d, yyyy')}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => window.open(file.url, '_blank')}
                            >
                              <ExternalLink className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteFile(deliverable.id, file.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}