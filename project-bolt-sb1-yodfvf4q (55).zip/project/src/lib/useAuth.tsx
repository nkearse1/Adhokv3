import { useState, useEffect } from 'react';
import { supabase } from '@supabase/supabaseClient';
import type { User } from '@supabase/supabase-js';

type UserRole = 'admin' | 'client' | 'talent' | null;

interface AuthState {
  authUser: User | null;
  userId: string | null;
  userRole: UserRole;
  username: string | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  loading: boolean;
}

export function useAuth(): AuthState {
  const [authUser, setAuthUser] = useState<User | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [username, setUsername] = useState<string | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  const loadSession = async () => {
    setLoading(true);

    try {
      const { data: { session }, error } = await supabase.auth.getSession();
      
      if (error || !session?.user) {
        setAuthUser(null);
        setIsAuthenticated(false);
        setUserId(null);
        setUserRole(null);
        setUsername(null);
        setIsAdmin(false);
        setLoading(false);
        return;
      }

      const user = session.user;
      setAuthUser(user);
      setUserId(user.id);
      setIsAuthenticated(true);

      // Get user role and username from user metadata instead of querying the users table
      const role = (user.user_metadata?.user_role as UserRole) || 'talent';
      const usernameFromMeta = user.user_metadata?.username || null;
      
      setUserRole(role);
      setUsername(usernameFromMeta);
      setIsAdmin(role === 'admin');

      setLoading(false);
    } catch (error) {
      console.error('Error loading session:', error);
      setAuthUser(null);
      setIsAuthenticated(false);
      setUserId(null);
      setUserRole(null);
      setUsername(null);
      setIsAdmin(false);
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
        loadSession();
      } else if (event === 'SIGNED_OUT') {
        setAuthUser(null);
        setIsAuthenticated(false);
        setUserId(null);
        setUserRole(null);
        setUsername(null);
        setIsAdmin(false);
        setLoading(false);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  return {
    authUser,
    userId,
    userRole,
    username,
    isAuthenticated,
    isAdmin,
    loading,
  };
}