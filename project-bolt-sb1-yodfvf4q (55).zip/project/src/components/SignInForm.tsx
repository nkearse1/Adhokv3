import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@supabase/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";

interface SignInFormProps {
  user_role?: string;
}

export function SignInForm({ user_role = 'client' }: SignInFormProps) {
  const navigate = useNavigate();
  const [identifier, setIdentifier] = useState(''); // Can be email or username
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      let email = identifier;
      
      // If identifier doesn't look like an email, try to find the user by username
      if (!identifier.includes('@')) {
        const { data, error: lookupError } = await supabase
          .rpc('get_user_by_username_or_email', { identifier });
          
        if (lookupError || !data || data.length === 0) {
          throw new Error('User not found');
        }
        
        email = data[0].email;
      }

      // Sign in with email and password
      const { data: authData, error: signInError } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (signInError || !authData?.user) {
        throw signInError || new Error('Invalid login credentials');
      }

      toast.success("Signed in successfully!");
      
      // Fetch user data to get the role
      const { data: userData, error: userError } = await supabase
        .from('users')
        .select('user_role, username')
        .eq('id', authData.user.id)
        .single();
        
      if (userError) {
        console.warn('Could not fetch user role from database:', userError);
      }
      
      // Determine redirect path based on user role
      const userRole = userData?.user_role || authData.user.user_metadata?.user_role || 'talent';
      const userId = authData.user.id;
      const username = userData?.username || authData.user.user_metadata?.username || userId;
      
      let redirectPath = '/';
      if (userRole === 'admin') {
        redirectPath = `/admin/${userId}/dashboard`;
      } else if (userRole === 'client') {
        redirectPath = `/client/${userId}/dashboard`;
      } else if (userRole === 'talent') {
        redirectPath = `/talent/${username}/dashboard`;
      }

      // Use replace instead of push to prevent back button from returning to login
      navigate(redirectPath, { replace: true });

    } catch (error: any) {
      console.error('Sign in error:', error);
      setError(error.message || 'Login failed');
      toast.error(error.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSignIn} className="max-w-md mx-auto space-y-4">
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Input
        placeholder="Email or Username"
        type="text"
        value={identifier}
        onChange={(e) => setIdentifier(e.target.value)}
        required
        autoComplete="username"
      />
      <Input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
        autoComplete="current-password"
      />
      <Button type="submit" disabled={loading} className="w-full">
        {loading ? 'Signing in...' : 'Sign In'}
      </Button>
    </form>
  );
}