import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/lib/supabaseClient";
import { toast } from "sonner";
import { 
  Loader2, Users, Briefcase, Activity,
  CheckCircle, XCircle, Search, Clock,
  ArrowRight, DollarSign, CreditCard, AlertTriangle, Flag, Shield
} from "lucide-react";
import { formatDistanceToNowStrict } from "date-fns";
import { useEscrow } from "@/hooks/useEscrow";
import EscrowHistoryTimeline from "@/components/EscrowHistoryTimeline";

const USE_MOCK_SESSION = true;

const mockProjects: Project[] = [
  {
    id: 'mock-project-1',
    title: 'Mock Marketing Campaign',
    description: 'Example project description',
    status: 'open',
    deadline: new Date().toISOString(),
    projectBudget: 1000,
    created_at: new Date().toISOString(),
    metadata: { marketing: { expertiseLevel: 'Pro Talent', budget: 1000 } },
    project_bids: [
      {
        id: 'bid-1',
        rate_per_hour: 75,
        professional: { full_name: 'Mock Talent' },
      },
    ],
  },
];

const mockTalents: TalentProfile[] = [
  {
    id: 'mock-talent-1',
    full_name: 'Mock Talent',
    email: 'talent@adhok.dev',
    expertise: 'SEO',
    is_qualified: true,
    created_at: new Date().toISOString(),
  },
];

const mockAdminProjects = [
  {
    id: "mock-proj-001",
    title: "Enterprise SEO Rollout",
    status: "submitted",
    category: "SEO Strategy",
    estimatedHours: 50,
    rate: 85,
    estimatedBudget: 4250,
    deadline: "2025-07-01",
    description: "Develop and implement an SEO strategy for an enterprise-level SaaS client.",
    problem: "Organic traffic is flatlining and technical visibility is low.",
    targetAudience: "Large B2B SaaS buyers",
    platforms: "Webflow, GA4",
    tools: "Screaming Frog, Ahrefs, Surfer",
    voice: "Authoritative but approachable",
    inspiration: ["https://example1.com", "https://example2.com"],
    deliverables: [
      { title: "Technical Audit Report" },
      { title: "Content Strategy Playbook" }
    ],
    client: {
      name: "Erica Jones",
      company: "SaaSmart Inc.",
      email: "erica@saasmart.io",
      phone: "555-234-9090"
    },
    talent: {
      name: "Alex Rivera",
      badge: "Expert Talent",
      portfolioUrl: "/talent/rivera/portfolio"
    },
    caseStudy: null
  },
  {
    id: "mock-proj-002",
    title: "Content Repurposing Initiative",
    status: "completed",
    category: "Content & Distribution",
    estimatedHours: 30,
    rate: 70,
    estimatedBudget: 2100,
    deadline: "2025-06-01",
    description: "Repurpose existing whitepapers and webinars into blog series and LinkedIn carousels.",
    problem: "Content library is underutilized and poorly distributed.",
    targetAudience: "Mid-sized agencies and digital marketers",
    platforms: "LinkedIn, HubSpot",
    tools: "Canva, ChatGPT, Notion",
    voice: "Conversational with an expert tone",
    inspiration: ["https://example3.com"],
    deliverables: [
      { title: "Repurposed Blog Series" },
      { title: "Social Snippets + Visuals" }
    ],
    client: {
      name: "Derek Lam",
      company: "GrowthNova",
      email: "d.lam@growthnova.com",
      phone: "555-988-1122"
    },
    talent: {
      name: "Monique Taylor",
      badge: "Pro Talent",
      portfolioUrl: "/talent/mtaylor/portfolio"
    },
    caseStudy: {
      summary: "Increased reach 4x by repackaging whitepapers into digestible LinkedIn content.",
      metrics: ["4x reach", "17% CTR on carousels", "12 qualified leads"],
      lessons: "Short-form value beats long-form formality. Lead with insight."
    }
  }
];


interface Project {
  id: string;
  title: string;
  description: string;
  status: string;
  deadline: string;
  projectBudget: number;
  created_at: string;
  flagged?: boolean;
  metadata?: {
    requestor?: {
      name?: string;
      email?: string;
    };
    marketing?: {
      expertiseLevel?: string;
      budget?: number;
    };
  };
  project_bids: {
    id: string;
    rate_per_hour: number;
    professional: {
      full_name: string;
    };
  }[];
}

interface TalentProfile {
  id: string;
  full_name: string;
  email: string;
  expertise: string;
  is_qualified: boolean;
  created_at: string;
}

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [projects, setProjects] = useState<Project[]>([]);
  const [talents, setTalents] = useState<TalentProfile[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredProjects, setFilteredProjects] = useState<Project[]>([]);
  const [filteredTalents, setFilteredTalents] = useState<TalentProfile[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [flagReason, setFlagReason] = useState("");

  // Initialize escrow hook for selected project
  const {
    escrowStatus,
    escrowHistory,
    requestEscrowRelease,
    approveEscrowRelease,
    rejectEscrowRelease,
    overrideEscrow,
    flagProjectForReview
  } = useEscrow(selectedProjectId || '');

  useEffect(() => {
    checkAuth();
    fetchDashboardData();

    const subscription = supabase
      .channel('dashboard_changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public' },
        () => fetchDashboardData()
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    // Filter projects
    const filtered = projects.filter(project => 
      project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.description.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setFilteredProjects(filtered);

    // Filter talents
    const filteredT = talents.filter(talent =>
      talent.full_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      talent.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      talent.expertise.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setFilteredTalents(filteredT);
  }, [searchQuery, projects, talents]);

  const checkAuth = async () => {
    try {
       if (USE_MOCK_SESSION) {
        return;
      }
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        toast.error('Please sign in to access admin panel');
        navigate('/admin/signin');
        return;
      }

      // Check admin role
      const { data: adminUser } = await supabase
        .from('admin_users')
        .select('id')
        .eq('id', session.user.id)
        .single();

      if (!adminUser) {
        toast.error('Unauthorized access');
        navigate('/');
        return;
      }
    } catch (error) {
      console.error('Error checking auth:', error);
      navigate('/');
    }
  };

  const fetchDashboardData = async () => {
    try {
       if (USE_MOCK_SESSION) {
        setProjects(mockProjects);
        setFilteredProjects(mockProjects);
        setTalents(mockTalents);
        setFilteredTalents(mockTalents);
        setLoading(false);
        return;
      }
      setLoading(true);

      // Fetch projects with proper UUID validation
      const { data: projectsData, error: projectsError } = await supabase
        .from('projects')
        .select(`
          *,
          project_bids!project_bids_project_id_fkey (
            id,
            rate_per_hour,
            professional:talent_profiles (
              full_name
            )
          )
        `)
        .order('created_at', { ascending: false });

      if (projectsError) throw projectsError;
      
      // Validate UUIDs before setting state
      const validProjects = projectsData?.filter(project => 
        project?.id && UUID_REGEX.test(project.id)
      ) || [];
      
      setProjects(validProjects);
      setFilteredProjects(validProjects);

      // Fetch talents with UUID validation
      const { data: talentsData, error: talentsError } = await supabase
        .from('talent_profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (talentsError) throw talentsError;

      const validTalents = talentsData?.filter(talent => 
        talent?.id && UUID_REGEX.test(talent.id)
      ) || [];

      setTalents(validTalents);
      setFilteredTalents(validTalents);

    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      toast.error('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return (
          <Badge variant="success\" className="flex items-center gap-1">
            <CheckCircle className="h-3 w-3" />
            Completed
          </Badge>
        );
      case 'in_progress':
        return (
          <Badge variant="secondary" className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            In Progress
          </Badge>
        );
      default:
        return (
          <Badge variant="outline" className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            Open
          </Badge>
        );
    }
  };

  const handleFlagProject = async () => {
    if (!flagReason.trim()) {
      toast.error('Please provide a reason for flagging');
      return;
    }
    
    await flagProjectForReview(flagReason);
    setFlagReason("");
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:justify-between sm:items-center mb-8">
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
          <div className="relative w-full sm:w-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              type="text"
              placeholder="Search..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 w-full sm:w-[300px]"
            />
          </div>
          <Button onClick={() => navigate('/admin/projects/new')}>
            New Project
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="projects">Projects</TabsTrigger>
          <TabsTrigger value="talents">Talents</TabsTrigger>
          <TabsTrigger value="escrow">Escrow Management</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Total Projects</p>
                    <p className="text-3xl font-bold">{projects.length}</p>
                  </div>
                  <div className="bg-blue-100 p-3 rounded-full">
                    <Briefcase className="h-5 w-5 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Active Talents</p>
                    <p className="text-3xl font-bold">{talents.length}</p>
                  </div>
                  <div className="bg-green-100 p-3 rounded-full">
                    <Users className="h-5 w-5 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Flagged Projects</p>
                    <p className="text-3xl font-bold">
                      {projects.filter(p => p.flagged).length}
                    </p>
                  </div>
                  <div className="bg-red-100 p-3 rounded-full">
                    <Flag className="h-5 w-5 text-red-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="projects">
          <div className="space-y-4">
            {filteredProjects.length === 0 ? (
              <Card>
                <CardContent className="p-6 text-center text-gray-500">
                  No projects found
                </CardContent>
              </Card>
            ) : (
              filteredProjects.map((project) => (
                <Card key={project?.id || Math.random()} className="overflow-hidden">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="text-xl font-semibold">{project?.title || 'Untitled Project'}</h3>
                          {project?.flagged && (
                            <Badge variant="destructive" className="flex items-center gap-1">
                              <Flag className="h-3 w-3" />
                              Flagged
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-3 mb-2">
                          {getStatusBadge(project?.status || 'unknown')}
                          <Badge variant="outline">
                            {project?.project_bids?.length || 0} bids
                          </Badge>
                          <span className="text-sm text-gray-500">
                            Due {project?.deadline ? formatDistanceToNowStrict(new Date(project.deadline)) : 'No deadline'}
                          </span>
                        </div>
                        <p className="text-gray-600">{project?.description || 'No description available'}</p>
                      </div>
                      <Button
                        variant="outline"
                        onClick={() => project?.id && navigate(`/admin/projects/${project.id}`)}
                        disabled={!project?.id}
                      >
                        View Details
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="talents">
          <div className="space-y-4">
            {filteredTalents.length === 0 ? (
              <Card>
                <CardContent className="p-6 text-center text-gray-500">
                  No talents found
                </CardContent>
              </Card>
            ) : (
              filteredTalents.map((talent) => (
                <Card key={talent.id}>
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-xl font-semibold mb-2">{talent.full_name}</h3>
                        <div className="flex items-center gap-3 mb-2">
                          <Badge variant={talent.is_qualified ? "success" : "secondary"}>
                            {talent.is_qualified ? (
                              <CheckCircle className="mr-1 h-3 w-3" />
                            ) : (
                              <XCircle className="mr-1 h-3 w-3" />
                            )}
                            {talent.is_qualified ? "Qualified" : "Pending"}
                          </Badge>
                          <Badge variant="outline">{talent.expertise}</Badge>
                        </div>
                        <p className="text-gray-600">{talent.email}</p>
                      </div>
                      <Button
                        variant="outline"
                        onClick={() => navigate(`/admin/talents/${talent.id}`)}
                      >
                        View Profile
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="escrow">
          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4">Escrow Management</h3>
                <p className="text-gray-600 mb-4">
                  Select a project to manage its escrow status and override payments if necessary.
                </p>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Select Project
                    </label>
                    <select
                      value={selectedProjectId || ''}
                      onChange={(e) => setSelectedProjectId(e.target.value || null)}
                      className="w-full p-2 border border-gray-300 rounded-md"
                    >
                      <option value="">Choose a project...</option>
                      {projects.map((project) => (
                        <option key={project.id} value={project.id}>
                          {project.title} - {project.status}
                          {project.flagged ? ' (FLAGGED)' : ''}
                        </option>
                      ))}
                    </select>
                  </div>

                  {selectedProjectId && (
                    <div className="border-t pt-4 space-y-6">
                      <div className="flex items-center gap-4 mb-4">
                        <Badge variant="outline" className="text-sm">
                          Escrow Status: {escrowStatus}
                        </Badge>
                        {projects.find(p => p.id === selectedProjectId)?.flagged && (
                          <Badge variant="destructive" className="text-sm">
                            Project Flagged
                          </Badge>
                        )}
                      </div>

                      {/* Fraud Prevention Section */}
                      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                        <div className="flex items-center gap-2 mb-3">
                          <Flag className="w-4 h-4 text-red-600" />
                          <h4 className="font-medium text-red-900">Fraud Prevention</h4>
                        </div>
                        <p className="text-sm text-red-800 mb-3">
                          Flag this project for review to freeze payments and restrict actions.
                        </p>
                        <div className="flex gap-2">
                          <Input
                            placeholder="Reason for flagging..."
                            value={flagReason}
                            onChange={(e) => setFlagReason(e.target.value)}
                            className="flex-1"
                          />
                          <Button 
                            onClick={handleFlagProject}
                            variant="destructive"
                            disabled={!flagReason.trim()}
                          >
                            <Flag className="w-4 h-4 mr-2" />
                            Flag Project
                          </Button>
                        </div>
                      </div>

                      {/* Admin Override Controls */}
                      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <AlertTriangle className="w-4 h-4 text-yellow-600" />
                          <h4 className="font-medium text-yellow-900">Admin Override Controls</h4>
                        </div>
                        <p className="text-sm text-yellow-800 mb-3">
                          Use these controls carefully. They bypass normal approval processes.
                        </p>
                        <div className="flex gap-2">
                          <Button 
                            onClick={() => overrideEscrow('release')}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <CreditCard className="w-4 h-4 mr-2" />
                            Force Release
                          </Button>
                          <Button 
                            onClick={() => overrideEscrow('cancel')}
                            variant="destructive"
                          >
                            <XCircle className="w-4 h-4 mr-2" />
                            Cancel Escrow
                          </Button>
                        </div>
                      </div>

                      {/* Pending Approval Section */}
                      {escrowStatus === 'requested' && (
                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                          <h4 className="font-medium text-blue-900 mb-2">Pending Approval</h4>
                          <p className="text-sm text-blue-800 mb-3">
                            This escrow release is awaiting client approval. You can override if necessary.
                          </p>
                          <div className="flex gap-2">
                            <Button onClick={approveEscrowRelease} size="sm">
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Admin Approve
                            </Button>
                            <Button 
                              onClick={() => rejectEscrowRelease('Admin rejection')} 
                              variant="outline" 
                              size="sm"
                            >
                              <XCircle className="w-4 h-4 mr-2" />
                              Admin Reject
                            </Button>
                          </div>
                        </div>
                      )}

                      {/* Escrow History Timeline */}
                      <EscrowHistoryTimeline history={escrowHistory} />
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}