// useProjectStatus.ts
import { useState, useEffect, useCallback } from 'react';
import { mockDeliverables } from '@/data/mockDeliverables';

export interface Deliverable {
  id: string;
  title: string;
  description: string;
  problem?: string;
  kpis?: string[];
  status: 'recommended' | 'scoped' | 'in_progress' | 'approved' | 'performance_tracking';
  estimatedHours: number;
  actualHours: number;
  timeEntries: Array<{
    startTime: Date;
    endTime?: Date;
    hoursLogged?: number;
  }>;
  dueDate?: Date;
  files?: Array<{
    id: string;
    name: string;
    url: string;
    uploadedAt: Date;
  }>;
  isTracking?: boolean;
  currentSession?: {
    startTime: Date;
  };
}

export interface Message {
  id: string;
  text: string;
  sender: 'client' | 'talent';
  timestamp: Date;
  deliverableId?: string;
}

const accessibleStatuses = ['Picked Up', 'Scope Defined', 'In Progress', 'Submitted', 'Revisions', 'Final Payment', 'Approved', 'Performance Tracking', 'Complete'];
const USE_MOCK_SESSION = true;

export function useProjectStatus(projectId?: string) {
  const [projectStatus, setProjectStatus] = useState<string>('Loading...');
  const [deliverables, setDeliverables] = useState<Deliverable[]>([]);
  const [activityLog, setActivityLog] = useState<string[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [hasTrackingInfo, setHasTrackingInfo] = useState(false);
  const [isArchived, setIsArchived] = useState(false);
  const [isAssignedToTalent, setIsAssignedToTalent] = useState(false);
  const [statusReady, setStatusReady] = useState(false);

  const calculateProjectStatus = useCallback(
    (items: Deliverable[], hasTracking: boolean, archived: boolean, assigned: boolean): string => {
      if (!assigned) return 'Live';
      if (items.length === 0) return 'Picked Up';

      const allApproved = items.every(d => d.status === 'approved' || d.status === 'performance_tracking');
      const anyInProgress = items.some(d => d.status === 'in_progress');
      const anyScoped = items.some(d => d.status === 'scoped');
      const anyRecommended = items.some(d => d.status === 'recommended');

      if (allApproved && hasTracking) return 'Complete';
      if (allApproved) return 'Approved';
      if (anyInProgress) return 'In Progress';
      if (anyScoped) return 'Scope Defined';
      if (anyRecommended) return 'Picked Up';
      return 'Picked Up';
    },
    []
  );

  useEffect(() => {
    if (USE_MOCK_SESSION) {
      const mockProjectDeliverables: Deliverable[] = mockDeliverables;
      setDeliverables(mockProjectDeliverables);
      setIsAssignedToTalent(true);
      setIsArchived(false);
      setHasTrackingInfo(false);

      const calculatedStatus = calculateProjectStatus(
        mockProjectDeliverables,
        false,
        false,
        true
      );

      setProjectStatus(calculatedStatus);
      setStatusReady(true);
      setLoading(false);

      setActivityLog([
        'Project auction completed',
        'Project assigned to talent',
        `Project status updated to: ${calculatedStatus}`,
        'Talent can now introduce themselves and review deliverables',
        'Chat is now available for communication'
      ]);

      setMessages([
        {
          id: 'init-1',
          sender: 'client',
          text: 'Welcome to the workspace! Let us know when you’re ready to begin.',
          timestamp: new Date(),
        }
      ]);
    }
  }, [projectId, calculateProjectStatus]);

  const canAccess = statusReady && accessibleStatuses.includes(projectStatus);

  const updateDeliverableStatus = useCallback((id: string, newStatus: Deliverable['status']) => {
    setDeliverables(prev => {
      const updated = prev.map(d => d.id === id ? { ...d, status: newStatus } : d);
      const newProjectStatus = calculateProjectStatus(updated, hasTrackingInfo, isArchived, isAssignedToTalent);
      setProjectStatus(newProjectStatus);
      return updated;
    });
    setActivityLog(prev => [...prev, `Deliverable status updated: ${newStatus}`]);
  }, [calculateProjectStatus, hasTrackingInfo, isArchived, isAssignedToTalent]);

  const addDeliverable = useCallback((deliverable: Partial<Deliverable>) => {
    const newDeliverable: Deliverable = {
      id: Date.now().toString(),
      title: deliverable.title || '',
      description: deliverable.description || '',
      problem: deliverable.problem || '',
      kpis: deliverable.kpis || [],
      status: 'recommended',
      estimatedHours: deliverable.estimatedHours || 0,
      actualHours: 0,
      timeEntries: [],
      ...deliverable
    };

    setDeliverables(prev => {
      const updated = [...prev, newDeliverable];
      const newProjectStatus = calculateProjectStatus(updated, hasTrackingInfo, isArchived, isAssignedToTalent);
      setProjectStatus(newProjectStatus);
      return updated;
    });
    setActivityLog(prev => [...prev, `New deliverable added: ${newDeliverable.title}`]);
  }, [calculateProjectStatus, hasTrackingInfo, isArchived, isAssignedToTalent]);

  const updateDeliverable = useCallback((id: string, updates: Partial<Deliverable>) => {
    setDeliverables(prev => prev.map(d => d.id === id ? { ...d, ...updates } : d));
    setActivityLog(prev => [...prev, 'Deliverable updated']);
  }, []);

  const addActivityLogEntry = useCallback((message: string) => {
    setActivityLog(prev => [...prev, message]);
  }, []);

  const addTrackingInfo = useCallback((trackingData: any) => {
    setHasTrackingInfo(true);
    setActivityLog(prev => [...prev, 'Performance tracking information added']);
    const newProjectStatus = calculateProjectStatus(deliverables, true, isArchived, isAssignedToTalent);
    setProjectStatus(newProjectStatus);
  }, [calculateProjectStatus, deliverables, isArchived, isAssignedToTalent]);

  const getApprovalProgress = useCallback(() => {
    const approvedCount = deliverables.filter(d => d.status === 'approved' || d.status === 'performance_tracking').length;
    const totalCount = deliverables.length;
    const percentage = totalCount > 0 ? Math.round((approvedCount / totalCount) * 100) : 0;
    return { approved: approvedCount, total: totalCount, percentage };
  }, [deliverables]);

  return {
    projectStatus,
    deliverables,
    activityLog,
    messages,
    setMessages,
    loading,
    statusReady,
    hasTrackingInfo,
    isArchived,
    isAssignedToTalent,
    canAccess,
    updateDeliverableStatus,
    addDeliverable,
    updateDeliverable,
    addActivityLogEntry,
    addTrackingInfo,
    getApprovalProgress
  };
}
