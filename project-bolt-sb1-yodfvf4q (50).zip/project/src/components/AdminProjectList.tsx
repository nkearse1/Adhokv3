import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search as SearchIcon } from "lucide-react";

const MOCK_PROJECTS = [
  {
    id: "proj-001",
    title: "SEO Overhaul for Startup",
    description: "Complete on-page and technical SEO for a VC-backed SaaS startup.",
    status: "in_progress",
    deadline: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
    project_bids: [{ id: "bid-1" }, { id: "bid-2" }],
    chatCount: 3,
    metadata: {
      marketing: {
        budget: 3000,
      },
    },
  },
  {
    id: "proj-002",
    title: "Landing Page Optimization",
    description: "Design and optimize a high-conversion landing page for Google Ads.",
    status: "completed",
    deadline: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    project_bids: [{ id: "bid-3" }],
    chatCount: 1,
    metadata: {
      marketing: {
        budget: 1200,
      },
    },
  },
  {
    id: "proj-003",
    title: "Blog Strategy Buildout",
    description: "Develop content strategy and create 10 pillar blog posts.",
    status: "open",
    deadline: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString(),
    project_bids: [],
    chatCount: 0,
    metadata: {
      marketing: {
        budget: 5000,
      },
    },
  },
];

export default function AdminProjectList() {
  const [projects] = useState(MOCK_PROJECTS);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [bidFilter, setBidFilter] = useState("all");
  const [revenueFilter, setRevenueFilter] = useState("all");
  const [deadlineFilter, setDeadlineFilter] = useState("all");

  const filteredProjects = projects.filter((project) => {
    const matchesSearch = project.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" || project.status === statusFilter;
    const matchesBids = bidFilter === "all" ||
      (bidFilter === "0" && (project.project_bids?.length || 0) === 0) ||
      (bidFilter === "1+" && (project.project_bids?.length || 0) > 0);
    const budget = project.metadata?.marketing?.budget || 0;
    const matchesRevenue = revenueFilter === "all" ||
      (revenueFilter === "low" && budget < 2000) ||
      (revenueFilter === "med" && budget >= 2000 && budget <= 4000) ||
      (revenueFilter === "high" && budget > 4000);
    const matchesDeadline = deadlineFilter === "all" ||
      (deadlineFilter === "past" && new Date(project.deadline) < new Date()) ||
      (deadlineFilter === "future" && new Date(project.deadline) >= new Date());
    return matchesSearch && matchesStatus && matchesBids && matchesRevenue && matchesDeadline;
  });

  return (
    <Card>
      <div className="flex flex-wrap gap-3 p-4">
        <Input
          type="text"
          placeholder="Search projects..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-[200px]"
        />
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="open">Open</SelectItem>
            <SelectItem value="in_progress">In Progress</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
          </SelectContent>
        </Select>
        <Select value={bidFilter} onValueChange={setBidFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Bids" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="0">0 Bids</SelectItem>
            <SelectItem value="1+">1+ Bids</SelectItem>
          </SelectContent>
        </Select>
        <Select value={revenueFilter} onValueChange={setRevenueFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Revenue" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="low">&lt; $2,000</SelectItem>
            <SelectItem value="med">$2,000–$4,000</SelectItem>
            <SelectItem value="high">&gt; $4,000</SelectItem>
          </SelectContent>
        </Select>
        <Select value={deadlineFilter} onValueChange={setDeadlineFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Deadline" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="past">Past</SelectItem>
            <SelectItem value="future">Upcoming</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <CardContent className="p-0 overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Title</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Bids</TableHead>
              <TableHead>Deadline</TableHead>
              <TableHead>Description</TableHead>
              <TableHead>UUID</TableHead>
              <TableHead>Total Revenue</TableHead>
              <TableHead>Platform Revenue</TableHead>
              <TableHead>Chats</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredProjects.map((project) => (
              <TableRow key={project.id}>
                <TableCell className="font-medium">{project.title}</TableCell>
                <TableCell>
                  <Badge variant="secondary">{project.status}</Badge>
                </TableCell>
                <TableCell>{project.project_bids?.length || 0}</TableCell>
                <TableCell>{project.deadline}</TableCell>
                <TableCell className="max-w-[250px] truncate">{project.description}</TableCell>
                <TableCell className="text-xs font-mono">{project.id}</TableCell>
                <TableCell>
                  ${project.metadata?.marketing?.budget?.toLocaleString() || 0}
                </TableCell>
                <TableCell>
                  ${((project.metadata?.marketing?.budget || 0) * 0.1).toLocaleString()}
                </TableCell>
                <TableCell>{project.chatCount}</TableCell>
                <TableCell>
                  <Button size="sm" variant="outline">
                    View
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
