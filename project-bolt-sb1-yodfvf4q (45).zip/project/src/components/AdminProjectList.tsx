import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ArrowRight, Clock, CheckCircle, Flag } from 'lucide-react';
import { formatDistanceToNowStrict } from 'date-fns';

interface Project {
  id?: string;
  title?: string;
  description?: string;
  status?: string;
  deadline?: string;
  project_bids?: { id: string }[];
  metadata?: {
    marketing?: {
      budget?: number;
    };
  };
}

interface AdminProjectListProps {
  projects: Project[];
}

export default function AdminProjectList({ projects }: AdminProjectListProps) {
  const navigate = useNavigate();
  const [flagged, setFlagged] = useState<Record<string, boolean>>({});

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return (
          <Badge variant="secondary" className="flex items-center gap-1">
            <CheckCircle className="h-3 w-3" />
            Completed
          </Badge>
        );
      case 'in_progress':
        return (
          <Badge variant="secondary" className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            In Progress
          </Badge>
        );
      default:
        return (
          <Badge variant="outline" className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            Open
          </Badge>
        );
    }
  };

  const toggleFlag = (id?: string) => {
    if (!id) return;
    setFlagged((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  if (!projects.length) {
    return (
      <Card>
        <CardContent className="p-6 text-center text-gray-500">
          No projects found
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="p-0 overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Title</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Bids</TableHead>
              <TableHead>Deadline</TableHead>
              <TableHead>Description</TableHead>
              <TableHead>UUID</TableHead>
              <TableHead>Total Revenue</TableHead>
              <TableHead>Platform Revenue</TableHead>
              <TableHead>Chats</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {projects.map((project) => (
              <TableRow key={project?.id || Math.random()}>
                <TableCell className="font-medium">
                  {project?.title || 'Untitled Project'}
                </TableCell>
                <TableCell>{getStatusBadge(project?.status || 'unknown')}</TableCell>
                <TableCell>{project?.project_bids?.length || 0}</TableCell>
                <TableCell>
                  {project?.deadline
                    ? formatDistanceToNowStrict(new Date(project.deadline))
                    : 'No deadline'}
                </TableCell>
                <TableCell className="max-w-[250px] truncate">
                  {project?.description || 'No description'}
                </TableCell>
                <TableCell className="text-xs font-mono">
                  {project?.id}
                </TableCell>
                <TableCell>
                  ${((project?.metadata?.marketing?.budget || 0)).toLocaleString()}
                </TableCell>
                <TableCell>
                  ${((project?.metadata?.marketing?.budget || 0) * 0.1).toLocaleString()}
                </TableCell>
                <TableCell>0</TableCell>
                <TableCell>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => project?.id && navigate(`/admin/projects/${project.id}`)}
                      disabled={!project?.id}
                      className="flex items-center gap-1"
                    >
                      View
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant={flagged[project?.id || ''] ? 'destructive' : 'outline'}
                      onClick={() => toggleFlag(project?.id)}
                    >
                      <Flag className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}