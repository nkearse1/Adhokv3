import { useState, useCallback, useEffect } from 'react';

export interface Deliverable {
  id: string;
  title: string;
  description: string;
  status: 'recommended' | 'scoped' | 'in_progress' | 'approved' | 'completed';
  estimatedHours: number;
  actualHours: number;
  timeEntries: Array<{
    startTime: Date;
    endTime?: Date;
    hoursLogged?: number;
  }>;
  files?: Array<{
    id: string;
    name: string;
    url: string;
    uploadedAt: Date;
  }>;
  isTracking?: boolean;
  currentSession?: {
    startTime: Date;
  };
}

// PERMANENT PROJECT STATUS MAPPING - DO NOT MODIFY WITHOUT EXPLICIT REQUEST
const PROJECT_STATUS_STEPS = [
  'Draft',
  'Live', 
  'Picked Up',
  'Initial Payment',
  'Scope Defined',
  'Submitted',
  'Draft Payment',
  'Revisions',
  'Approved',
  'Final Payment',
  'Completed'
] as const;

export type ProjectStatus = typeof PROJECT_STATUS_STEPS[number];

/**
 * PERMANENT PROJECT STATUS CALCULATOR
 * CRITICAL RULE: Talent should ONLY see workspace when project is "Picked Up" or beyond
 * This means deliverables must exist (talent has picked up the project)
 * DO NOT MODIFY WITHOUT EXPLICIT REQUEST
 */
function calculateProjectStatus(deliverables: Deliverable[]): ProjectStatus {
  // CRITICAL: If no deliverables exist, talent hasn't picked up the project yet
  if (deliverables.length === 0) return 'Live';
  
  // CRITICAL: If deliverables exist, talent has picked up the project
  const hasRecommended = deliverables.some(d => d.status === 'recommended');
  const hasScoped = deliverables.some(d => d.status === 'scoped');
  const hasInProgress = deliverables.some(d => d.status === 'in_progress');
  const hasApproved = deliverables.some(d => d.status === 'approved');
  const hasCompleted = deliverables.some(d => d.status === 'completed');
  
  const allCompleted = deliverables.length > 0 && deliverables.every(d => d.status === 'completed');
  const allApprovedOrCompleted = deliverables.length > 0 && deliverables.every(d => d.status === 'approved' || d.status === 'completed');
  const allScopedOrBeyond = deliverables.length > 0 && deliverables.every(d => ['scoped', 'in_progress', 'approved', 'completed'].includes(d.status));
  
  // Status progression logic - PERMANENT
  if (allCompleted) return 'Completed';
  if (hasCompleted && allApprovedOrCompleted) return 'Final Payment';
  if (hasApproved) return 'Approved';
  if (hasInProgress) return 'Submitted';
  if (allScopedOrBeyond && hasScoped) return 'Scope Defined';
  
  // CRITICAL: If deliverables exist (any status), project is "Picked Up"
  // This is the minimum status for talent workspace access
  return 'Picked Up';
}

/**
 * PERMANENT PROJECT STATUS HOOK
 * This hook manages project status and ensures all components stay in sync
 * DO NOT MODIFY THE CORE LOGIC WITHOUT EXPLICIT REQUEST
 */
export function useProjectStatus(initialDeliverables: Deliverable[] = []) {
  const [deliverables, setDeliverables] = useState<Deliverable[]>(initialDeliverables);
  const [activityLog, setActivityLog] = useState<string[]>(['Project picked up by talent', 'Initial deliverables recommended']);
  
  // PERMANENT: Calculate project status from deliverables
  const projectStatus = calculateProjectStatus(deliverables);
  
  // PERMANENT: Log activity when status changes
  useEffect(() => {
    const currentStatus = calculateProjectStatus(deliverables);
    const lastLogEntry = activityLog[activityLog.length - 1];
    const statusChangeMessage = `Project status updated to: ${currentStatus}`;
    
    if (!lastLogEntry?.includes(statusChangeMessage)) {
      setActivityLog(prev => [...prev, statusChangeMessage]);
    }
  }, [deliverables, activityLog]);
  
  // PERMANENT: Update deliverable status
  const updateDeliverableStatus = useCallback((id: string, newStatus: Deliverable['status']) => {
    setDeliverables(prev => {
      const updated = prev.map(d => 
        d.id === id ? { ...d, status: newStatus } : d
      );
      
      // Log the change
      const deliverable = prev.find(d => d.id === id);
      if (deliverable) {
        setActivityLog(prevLog => [...prevLog, `Deliverable "${deliverable.title}" moved to ${newStatus}`]);
      }
      
      return updated;
    });
  }, []);
  
  // PERMANENT: Add new deliverable
  const addDeliverable = useCallback((newDeliverable: Partial<Deliverable>) => {
    const fullDeliverable: Deliverable = {
      id: Date.now().toString(),
      actualHours: 0,
      timeEntries: [],
      files: [],
      ...newDeliverable
    } as Deliverable;
    
    setDeliverables(prev => [...prev, fullDeliverable]);
    setActivityLog(prev => [...prev, `New deliverable recommended: ${newDeliverable.title}`]);
  }, []);
  
  // PERMANENT: Update deliverable
  const updateDeliverable = useCallback((id: string, updates: Partial<Deliverable>) => {
    setDeliverables(prev => prev.map(d => 
      d.id === id ? { ...d, ...updates } : d
    ));
    
    if (updates.files) {
      const deliverable = deliverables.find(d => d.id === id);
      if (deliverable) {
        setActivityLog(prev => [...prev, `Files updated for deliverable: ${deliverable.title}`]);
      }
    }
    
    if (updates.timeEntries) {
      const deliverable = deliverables.find(d => d.id === id);
      if (deliverable) {
        setActivityLog(prev => [...prev, `Time logged for deliverable: ${deliverable.title}`]);
      }
    }
  }, [deliverables]);
  
  // PERMANENT: Add activity log entry
  const addActivityLogEntry = useCallback((entry: string) => {
    setActivityLog(prev => [...prev, entry]);
  }, []);
  
  return {
    // PERMANENT: Core state
    projectStatus,
    deliverables,
    activityLog,
    
    // PERMANENT: Actions
    updateDeliverableStatus,
    addDeliverable,
    updateDeliverable,
    addActivityLogEntry,
    
    // PERMANENT: Utilities
    PROJECT_STATUS_STEPS
  };
}