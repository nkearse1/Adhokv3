import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { CalendarIcon, SendIcon, Clock, AlertCircle, ExternalLink } from 'lucide-react';
import { format, formatDistanceToNow } from 'date-fns';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import ProjectTimeline from '@/components/ProjectTimeline';
import DeliverablesPanel from '@/components/DeliverablesPanel';
import ActivityLog from '@/components/ActivityLog';
import { useProjectStatus } from '@/hooks/useProjectStatus';
import { toast } from 'sonner';
import data from '@emoji-mart/data';
import Picker from '@emoji-mart/react';

export default function ProjectWorkspace() {
  const { id } = useParams();
  const [projectName] = useState("SEO Optimization");
  const [projectDeadline] = useState(new Date(Date.now() + 14 * 24 * 60 * 60 * 1000));
  const [projectStartDate] = useState(new Date());
  const [estimatedHours] = useState(40);
  const [hourlyRate] = useState(75);
  const [estimatedBudget] = useState(estimatedHours * hourlyRate);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Array<{
    id: string;
    text: string;
    sender: string;
    timestamp: Date;
    read?: boolean;
  }>>([]);
  const [hasInitialMessage, setHasInitialMessage] = useState(false);

  // PERMANENT: Use centralized project status management
  const {
    projectStatus,
    deliverables,
    activityLog,
    updateDeliverableStatus,
    addDeliverable,
    updateDeliverable,
    addActivityLogEntry
  } = useProjectStatus([
    {
      id: '1',
      title: 'Initial SEO Audit',
      description: 'Complete analysis of current SEO performance',
      status: 'recommended',
      estimatedHours: 8,
      actualHours: 0,
      timeEntries: [],
      files: []
    },
    {
      id: '2',
      title: 'Keyword Research',
      description: 'Identify target keywords and search intent',
      status: 'recommended',
      estimatedHours: 12,
      actualHours: 0,
      timeEntries: [],
      files: []
    }
  ]);

  useEffect(() => {
    if (messages.length > 0) {
      const timeout = setTimeout(() => setIsTyping(false), 3000);
      setIsTyping(true);
      return () => clearTimeout(timeout);
    }
  }, [messages]);

  useEffect(() => {
    setHasInitialMessage(messages.length > 0);
  }, [messages]);

  const handleSend = () => {
    if (message.trim()) {
      setMessages((msgs) => [
        ...msgs,
        { id: String(Date.now()), text: message, sender: 'talent', timestamp: new Date(), read: false },
      ]);
      setMessage('');
      setShowEmojiPicker(false);
      addActivityLogEntry(`Sent message: ${message.slice(0, 50)}${message.length > 50 ? '...' : ''}`);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const addEmoji = (e: any) => {
    setMessage((prev) => prev + e.native);
  };

  return (
    <div className="min-h-screen bg-[#F0F4FF]">
      <div className="max-w-5xl mx-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-[#2E3A8C]">{projectName}</h1>
        </div>

        {/* PERMANENT: ProjectTimeline uses centralized status */}
        <ProjectTimeline status={projectStatus} />

        <div className="bg-white border border-[#E6E9F4] rounded-lg p-4 mb-6">
          <div className="flex justify-between items-start">
            <div>
              <div className="flex items-center gap-3">
                {/* PERMANENT: Badge shows centralized status */}
                <Badge variant="secondary">
                  <Clock className="mr-1 h-3 w-3" />
                  {projectStatus}
                </Badge>
                <Badge variant="outline" className="bg-yellow-50 text-yellow-800 border-yellow-200">
                  Due {formatDistanceToNow(projectDeadline, { addSuffix: true })}
                </Badge>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  asChild 
                  className="text-[#2E3A8C] hover:text-[#1B276F]"
                >
                  <Link to={`/talent/projects/${id}/details`} className="flex items-center gap-1">
                    <ExternalLink className="h-4 w-4" />
                    View Details
                  </Link>
                </Button>
              </div>
              <div className="flex items-center gap-4 text-sm text-gray-600">
                <div className="flex items-center gap-2">
                  <CalendarIcon className="w-4 h-4 text-[#2E3A8C]" />
                  <span>Deadline: {format(projectDeadline, 'PPP')}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-[#2E3A8C]" />
                  <span>{estimatedHours} hours @ ${hourlyRate}/hr</span>
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm font-medium text-[#2E3A8C]">
                Total Budget: ${estimatedBudget.toLocaleString()}
              </div>
            </div>
          </div>
        </div>

        {!hasInitialMessage && (
          <Alert className="mb-6 bg-blue-50 border-blue-200">
            <AlertCircle className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-blue-800">
              Welcome to your new project! Please introduce yourself to the client and recommend initial deliverables to get started.
            </AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="deliverables" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-white mb-6 rounded-lg border border-[#E6E9F4]">
            <TabsTrigger value="chat">Chat</TabsTrigger>
            <TabsTrigger value="deliverables">Deliverables</TabsTrigger>
            <TabsTrigger value="activity">Activity Log</TabsTrigger>
          </TabsList>

          <TabsContent value="deliverables">
            {/* PERMANENT: DeliverablesPanel uses centralized state */}
            <DeliverablesPanel 
              role="talent"
              deliverables={deliverables}
              editable
              showForm
              projectDeadline={projectDeadline}
              projectStartDate={projectStartDate}
              onAddDeliverable={addDeliverable}
              onStatusChange={updateDeliverableStatus}
              onUpdateDeliverable={updateDeliverable}
            />
          </TabsContent>

          <TabsContent value="chat">
            <div className="bg-white border border-[#E6E9F4] rounded-lg shadow-lg flex flex-col">
              <div className="flex-1 p-4 space-y-4 max-h-[500px] overflow-y-auto">
                {messages.map((msg) => (
                  <div key={msg.id} className={`flex ${msg.sender === 'talent' ? 'justify-end' : 'justify-start'}`}>
                    <div 
                      className={`max-w-[70%] ${
                        msg.sender === 'talent' 
                          ? 'bg-[#E6E9F4] text-[#2E3A8C]' 
                          : 'bg-[#E6FCF9] text-[#00A499]'
                      } rounded-lg p-3`}
                    >
                      <div className="text-xs opacity-75 mb-1">{format(msg.timestamp, 'p')}</div>
                      <p className="whitespace-pre-wrap">{msg.text}</p>
                    </div>
                  </div>
                ))}
                {isTyping && (
                  <div className="text-gray-500 italic text-sm">Client is typing...</div>
                )}
              </div>
              <div className="border-t border-[#E6E9F4] p-4">
                <div className="flex gap-2">
                  <Input
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Type a message..."
                    className="flex-1 bg-white border-[#E6E9F4]"
                  />
                  <Button
                    onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                    className="bg-white border border-[#E6E9F4] text-[#00A499] hover:bg-[#E6E9F4]"
                  >
                    😊
                  </Button>
                  <Button 
                    onClick={handleSend}
                    className="bg-[#00A499] text-white hover:bg-[#00A499]/90"
                  >
                    <SendIcon className="w-4 h-4" />
                  </Button>
                </div>
                {showEmojiPicker && (
                  <div className="absolute mt-2">
                    <Picker data={data} onEmojiSelect={addEmoji} theme="light" />
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="activity">
            {/* PERMANENT: ActivityLog uses centralized state */}
            <ActivityLog
              role="talent"
              deliverables={deliverables}
              activityLog={activityLog}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}