import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { AlertTriangle, CheckCircle, Flag } from 'lucide-react';

const mockTalent = {
  id: 'mock-talent-1',
  name: 'Mock Talent',
  email: 'mock@adhok.dev',
  badge: 'Pro Talent',
  location: 'Austin, TX',
  portfolioUrl: '/talent/mock-talent-1/portfolio',
  status: 'qualified',
  joinMethod: 'invited',
  activity: ['Bidded on “SEO Audit”', 'Won “Social Media Strategy”', 'Viewed 5 projects'],
  reviews: [
    { reviewer: 'Client A', score: 4.5, feedback: 'Solid communication and delivered early' },
    { reviewer: 'Client B', score: 3.0, feedback: 'Good work but missed brand tone' },
  ],
  indicators: {
    positives: ['Completed 2 projects', 'High response rate'],
    negatives: ['1 flagged deliverable', '1 late submission'],
  },
};

export default function AdminTalentDetails() {
  const navigate = useNavigate();

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-[#2E3A8C]">{mockTalent.name}</h1>
        <div className="space-x-2">
          <Button variant="outline" onClick={() => alert('Talent qualified')}>Qualify</Button>
          <Button variant="outline" onClick={() => alert('Talent disqualified')}>Disqualify</Button>
          <Button variant="destructive" onClick={() => alert('Talent flagged for admin review')}>
            <Flag className="w-4 h-4 mr-1" /> Flag
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-4">
          <p><strong>Email:</strong> {mockTalent.email}</p>
          <p><strong>Location:</strong> {mockTalent.location}</p>
          <p><strong>Status:</strong> <Badge variant="success">{mockTalent.status}</Badge></p>
          <p><strong>Join Method:</strong> <Badge variant="secondary">{mockTalent.joinMethod}</Badge></p>
          <p className="mt-2">
            <a href={mockTalent.portfolioUrl} className="text-blue-600 underline">View Portfolio</a>
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <h2 className="font-semibold text-lg mb-2">Platform Activity</h2>
          <ul className="list-disc pl-5 text-sm text-gray-700">
            {mockTalent.activity.map((item, i) => <li key={i}>{item}</li>)}
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <h2 className="font-semibold text-lg mb-2">Reviews</h2>
          {mockTalent.reviews.map((r, i) => (
            <div key={i} className="mb-2">
              <p className="font-medium">{r.reviewer}</p>
              <p className="text-sm text-gray-700">⭐ {r.score} - {r.feedback}</p>
            </div>
          ))}
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardContent className="p-4">
            <h2 className="font-semibold text-lg mb-2 text-green-700"><CheckCircle className="inline w-4 h-4 mr-1" /> Positive Indicators</h2>
            <ul className="list-disc pl-5 text-sm text-green-700">
              {mockTalent.indicators.positives.map((p, i) => <li key={i}>{p}</li>)}
            </ul>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <h2 className="font-semibold text-lg mb-2 text-red-700"><AlertTriangle className="inline w-4 h-4 mr-1" /> Negative Indicators</h2>
            <ul className="list-disc pl-5 text-sm text-red-700">
              {mockTalent.indicators.negatives.map((n, i) => <li key={i}>{n}</li>)}
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
