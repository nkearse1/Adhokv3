// AdminDashboard.tsx
import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Users, Flag, Briefcase, DollarSign, ThumbsDown } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import AdminTalentList from '@/components/AdminTalentList';
import AdminProjectList from '@/components/AdminProjectList';
import RevenuePanel from '@/components/RevenuePanel';

const metrics = [
  { key: 'totalProjects', label: 'Total Projects', icon: Briefcase, color: 'bg-blue-100', value: 1 },
  { key: 'activeTalents', label: 'Active Talents', icon: Users, color: 'bg-green-100', value: 1 },
  { key: 'flaggedProjects', label: 'Flagged Projects', icon: Flag, color: 'bg-red-100', value: 0 },
  { key: 'estRevenue', label: 'Est. Revenue', icon: DollarSign, color: 'bg-yellow-100', value: 4200 },
  { key: 'revPerTalent', label: 'Rev. per Active Talent', icon: DollarSign, color: 'bg-purple-100', value: 4200 },
  { key: 'negReviews', label: 'Negative Reviews', icon: ThumbsDown, color: 'bg-pink-100', value: 2 }
];

const chartData = [
  { time: 'Week 1', totalProjects: 1, estRevenue: 1500, activeTalents: 1, revPerTalent: 1500, flaggedProjects: 0, negReviews: 0 },
  { time: 'Week 2', totalProjects: 2, estRevenue: 3000, activeTalents: 1, revPerTalent: 3000, flaggedProjects: 0, negReviews: 1 },
  { time: 'Week 3', totalProjects: 3, estRevenue: 4200, activeTalents: 1, revPerTalent: 4200, flaggedProjects: 1, negReviews: 2 }
];

export default function AdminDashboard() {
  const [activeLines, setActiveLines] = useState<string[]>(['totalProjects', 'activeTalents']);

  const toggleLine = (key: string) => {
    setActiveLines((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]
    );
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-[#2E3A8C]">Admin Dashboard</h1>
        <Button>New Project</Button>
      </div>

      <Tabs defaultValue="overview" className="mb-6">
      <TabsList>
        <TabsTrigger value="overview">Overview</TabsTrigger>
        <TabsTrigger value="projects">Projects</TabsTrigger>
        <TabsTrigger value="talents">Talent</TabsTrigger>
        <TabsTrigger value="revenue">Revenue</TabsTrigger>
 </TabsList>

        <TabsContent value="overview">
          <div className="flex gap-4 overflow-x-auto pb-4">
            {metrics.map(({ key, label, icon: Icon, color, value }) => (
              <Card
                key={key}
                onClick={() => toggleLine(key)}
                className={`min-w-[160px] cursor-pointer ${activeLines.includes(key) ? 'border-[#2E3A8C]' : ''}`}
              >
                <CardContent className="p-4 space-y-2">
                  <div className={`rounded-full w-8 h-8 flex items-center justify-center ${color}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <p className="text-sm text-gray-500">{label}</p>
                  <p className="text-xl font-bold">{value}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="bg-white rounded-lg shadow p-6 mt-6 h-[360px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
                <XAxis dataKey="time" stroke="#2E3A8C" />
                <YAxis stroke="#2E3A8C" />
                <Tooltip />
                <Legend />
                {activeLines.map((key) => (
                  <Line key={key} type="monotone" dataKey={key} stroke="#00A499" strokeWidth={2} />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </div>
        </TabsContent>

        <TabsContent value="projects">
          <AdminProjectList />
        </TabsContent>

        <TabsContent value="talents">
          <AdminTalentList />
        </TabsContent>

        <TabsContent value="revenue">
          <RevenuePanel />
        </TabsContent>
      </Tabs>
    </div>
  );
}
